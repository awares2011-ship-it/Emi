import type { Metadata } from 'next';
import { getAllPosts } from '@/lib/blog';
import BlogCard from '@/components/BlogCard';
import AdBanner from '@/components/AdBanner';
import Link from 'next/link';

// FIX: searchParams requires dynamic rendering in Next.js 14
export const dynamic = 'force-dynamic';

export const metadata: Metadata = {
  title: 'Finance Blog India – EMI, SIP, Tax & Investment Guides 2026',
  description: 'Expert personal finance articles for India. In-depth guides on EMI, SIP, home loans, income tax, FD, GST, and smart investing. Updated monthly.',
  keywords: ['finance blog India', 'SIP guide India', 'EMI tips', 'income tax saving', 'mutual fund guide India 2026'],
  alternates: { canonical: 'https://fintoolsindia.in/blog' },
  openGraph: {
    title: 'Finance Blog India – EMI, SIP, Tax & Investment Guides 2026',
    description: 'Expert personal finance articles for India. EMI, SIP, tax saving, and smart investing.',
    url: 'https://fintoolsindia.in/blog',
    type: 'website',
  },
};

const CATEGORIES = ['All', 'EMI', 'SIP', 'Tax', 'FD', 'GST', 'General'];

export default async function BlogPage({
  searchParams,
}: {
  searchParams: { category?: string };
}) {
  const posts = await getAllPosts();
  const cat = searchParams.category?.toLowerCase();
  const filtered =
    cat && cat !== 'all' ? posts.filter((p) => p.category === cat) : posts;

  return (
    <div className="max-w-6xl mx-auto px-4 py-10">
      {/* Breadcrumb */}
      <nav className="text-xs mb-6 flex items-center gap-2" style={{ color: 'var(--text-muted)' }}>
        <Link href="/" className="hover:underline">Home</Link>
        <span>/</span>
        <span style={{ color: 'var(--emerald)' }}>Blog</span>
      </nav>

      <div className="mb-10">
        <h1
          className="font-serif text-4xl md:text-5xl font-bold mb-3"
          style={{ color: 'var(--text-primary)' }}
        >
          Finance Blog India
        </h1>
        <p className="text-lg" style={{ color: 'var(--text-secondary)' }}>
          Expert guides on EMI, SIP, income tax, FD, GST, and smart investing for Indians
        </p>
      </div>

      <AdBanner slot="6666666666" format="horizontal" style={{ height: 90, marginBottom: 32 }} />

      {/* Category Filters */}
      <div className="flex flex-wrap gap-2 mb-8">
        {CATEGORIES.map((c) => {
          const isActive = (!cat && c === 'All') || cat === c.toLowerCase();
          return (
            <Link
              key={c}
              href={c === 'All' ? '/blog' : `/blog?category=${c.toLowerCase()}`}
              className="px-4 py-2 rounded-full text-sm font-medium border transition-colors"
              style={{
                borderColor: isActive ? 'var(--emerald)' : 'var(--border)',
                background: isActive ? 'var(--emerald-light)' : 'var(--bg-card)',
                color: isActive ? 'var(--emerald)' : 'var(--text-secondary)',
              }}
            >
              {c}
            </Link>
          );
        })}
      </div>

      {filtered.length === 0 ? (
        <div className="text-center py-20">
          <p className="text-4xl mb-4">📝</p>
          <h2
            className="font-serif text-2xl font-bold mb-2"
            style={{ color: 'var(--text-primary)' }}
          >
            Articles Coming Soon
          </h2>
          <p className="mb-6" style={{ color: 'var(--text-secondary)' }}>
            We&apos;re writing expert finance guides for India. Check back soon!
          </p>
          <Link
            href="/"
            className="px-6 py-3 rounded-xl text-sm font-semibold text-white"
            style={{ background: 'var(--emerald)' }}
          >
            Try Our Calculators →
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filtered.map((post) => (
            <BlogCard key={post.id} post={post} />
          ))}
        </div>
      )}

      {/* Calculator CTA strip */}
      <section className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-4">
        {[
          { href: '/tools/emi-calculator',        label: '🏠 EMI Calculator',  color: 'var(--emerald)' },
          { href: '/tools/sip-calculator',        label: '📈 SIP Calculator',  color: 'var(--plum)' },
          { href: '/tools/income-tax-calculator', label: '📊 Tax Calculator',  color: 'var(--coral)' },
        ].map((c) => (
          <Link
            key={c.href}
            href={c.href}
            className="rounded-2xl border p-5 text-center hover:-translate-y-1 transition-transform"
            style={{ background: 'var(--bg-card)', borderColor: 'var(--border)' }}
          >
            <p className="font-semibold" style={{ color: c.color }}>
              {c.label} →
            </p>
          </Link>
        ))}
      </section>
    </div>
  );
}
