'use client';
import { useState, useEffect } from 'react';
import { RotateCcw } from 'lucide-react';

const fmt = (n: number) => '₹' + n.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
type Mode = 'exclusive' | 'inclusive';

const GST_RATES = [5, 12, 18, 28];

export default function GSTCalculator() {
  const [amount, setAmount] = useState(10000);
  const [gstRate, setGstRate] = useState(18);
  const [mode, setMode] = useState<Mode>('exclusive');
  const [results, setResults] = useState({ gstAmt: 0, cgst: 0, sgst: 0, total: 0, preGst: 0 });

  useEffect(() => {
    if (mode === 'exclusive') {
      const gstAmt = (amount * gstRate) / 100;
      setResults({ gstAmt, cgst: gstAmt / 2, sgst: gstAmt / 2, total: amount + gstAmt, preGst: amount });
    } else {
      const preGst = (amount * 100) / (100 + gstRate);
      const gstAmt = amount - preGst;
      setResults({ gstAmt, cgst: gstAmt / 2, sgst: gstAmt / 2, total: amount, preGst });
    }
  }, [amount, gstRate, mode]);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
      <div className="rounded-2xl border p-6 space-y-6" style={{ background: 'var(--bg-card)', borderColor: 'var(--border)' }}>
        <div>
          <label className="text-sm font-semibold block mb-3" style={{ color: 'var(--text-secondary)' }}>Calculation Mode</label>
          <div className="grid grid-cols-2 gap-2">
            {(['exclusive', 'inclusive'] as Mode[]).map(m => (
              <button key={m} onClick={() => setMode(m)} className="py-2.5 px-4 rounded-xl border text-sm font-medium capitalize transition-colors" style={{ borderColor: mode === m ? 'var(--emerald)' : 'var(--border)', background: mode === m ? 'var(--emerald-light)' : 'var(--bg-subtle)', color: mode === m ? 'var(--emerald)' : 'var(--text-secondary)' }}>
                {m === 'exclusive' ? 'Add GST' : 'Remove GST'}
              </button>
            ))}
          </div>
          <p className="text-xs mt-2" style={{ color: 'var(--text-muted)' }}>
            {mode === 'exclusive' ? 'Enter base price, GST will be added' : 'Enter price inclusive of GST, we extract it'}
          </p>
        </div>

        <div>
          <div className="flex justify-between mb-2">
            <label className="text-sm font-semibold" style={{ color: 'var(--text-secondary)' }}>{mode === 'exclusive' ? 'Base Amount (Ex-GST)' : 'Amount (Inc-GST)'}</label>
          </div>
          <input type="number" value={amount} onChange={e => setAmount(+e.target.value)} className="w-full px-4 py-3 rounded-xl border text-sm font-medium" style={{ background: 'var(--bg-subtle)', borderColor: 'var(--border)', color: 'var(--text-primary)', outline: 'none' }} placeholder="Enter amount" />
        </div>

        <div>
          <label className="text-sm font-semibold block mb-3" style={{ color: 'var(--text-secondary)' }}>GST Rate</label>
          <div className="grid grid-cols-4 gap-2">
            {GST_RATES.map(r => (
              <button key={r} onClick={() => setGstRate(r)} className="py-2.5 rounded-xl border text-sm font-semibold transition-colors" style={{ borderColor: gstRate === r ? 'var(--amber)' : 'var(--border)', background: gstRate === r ? 'var(--amber-light)' : 'var(--bg-subtle)', color: gstRate === r ? 'var(--amber)' : 'var(--text-secondary)' }}>
                {r}%
              </button>
            ))}
          </div>
          <div className="mt-3 flex items-center gap-2">
            <span className="text-sm" style={{ color: 'var(--text-muted)' }}>Custom:</span>
            <input type="number" value={gstRate} onChange={e => setGstRate(+e.target.value)} className="flex-1 px-4 py-2 rounded-xl border text-sm font-medium" style={{ background: 'var(--bg-subtle)', borderColor: 'var(--border)', color: 'var(--text-primary)', outline: 'none' }} placeholder="Custom %" />
          </div>
        </div>

        <button onClick={() => { setAmount(10000); setGstRate(18); setMode('exclusive'); }} className="flex items-center gap-2 px-4 py-2.5 rounded-xl border text-sm font-medium" style={{ borderColor: 'var(--border)', color: 'var(--text-secondary)', background: 'var(--bg-subtle)' }}>
          <RotateCcw size={14} /> Reset
        </button>
      </div>

      <div className="space-y-4">
        <div className="rounded-2xl p-6" style={{ background: 'linear-gradient(135deg, var(--coral-light), var(--bg-card))', border: '1px solid var(--coral-light)' }}>
          <p className="text-sm font-medium mb-1" style={{ color: 'var(--coral)' }}>Total GST Amount</p>
          <p className="font-serif text-5xl font-bold mb-1" style={{ color: 'var(--text-primary)' }}>{fmt(results.gstAmt)}</p>
          <p className="text-xs" style={{ color: 'var(--text-muted)' }}>@ {gstRate}% GST rate</p>
        </div>

        <div className="rounded-2xl border p-5 space-y-3" style={{ background: 'var(--bg-card)', borderColor: 'var(--border)' }}>
          {[
            { label: 'Pre-GST Amount', value: results.preGst, color: 'var(--text-primary)' },
            { label: `CGST (${gstRate / 2}%)`, value: results.cgst, color: 'var(--amber)' },
            { label: `SGST (${gstRate / 2}%)`, value: results.sgst, color: 'var(--amber)' },
            { label: 'Total GST', value: results.gstAmt, color: 'var(--coral)' },
            { label: 'Final Amount (Inc. GST)', value: results.total, color: 'var(--emerald)' },
          ].map(row => (
            <div key={row.label} className="flex justify-between items-center py-2 border-b last:border-0 last:pt-2 last:font-bold" style={{ borderColor: 'var(--border)' }}>
              <span className="text-sm" style={{ color: 'var(--text-secondary)' }}>{row.label}</span>
              <span className="text-sm font-semibold" style={{ color: row.color }}>{fmt(row.value)}</span>
            </div>
          ))}
        </div>

        <div className="rounded-xl p-4 border" style={{ background: 'var(--bg-subtle)', borderColor: 'var(--border)' }}>
          <p className="text-xs font-semibold mb-2" style={{ color: 'var(--text-secondary)' }}>GST Slabs in India</p>
          <div className="space-y-1 text-xs" style={{ color: 'var(--text-muted)' }}>
            <p><strong>0%</strong> – Essential goods (milk, eggs, vegetables)</p>
            <p><strong>5%</strong> – Daily use items, transport services</p>
            <p><strong>12%</strong> – Processed foods, mobile phones</p>
            <p><strong>18%</strong> – Most services, electronics, restaurants</p>
            <p><strong>28%</strong> – Luxury items, automobiles, tobacco</p>
          </div>
        </div>
      </div>
    </div>
  );
}
