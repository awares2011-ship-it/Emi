'use client';
import { useState, useEffect, useRef, useCallback } from 'react';
import { Chart, ArcElement, Tooltip, Legend, DoughnutController } from 'chart.js';
import Link from 'next/link';
import { RotateCcw, Copy, Check } from 'lucide-react';

Chart.register(ArcElement, Tooltip, Legend, DoughnutController);

const fmt = (n: number) => '₹' + Math.round(n).toLocaleString('en-IN');

export default function EmiCalculator() {
  const [principal, setPrincipal] = useState(1000000);
  const [rate, setRate] = useState(8.5);
  const [tenure, setTenure] = useState(20);
  const [results, setResults] = useState({ emi: 0, totalPayment: 0, totalInterest: 0 });
  const [copied, setCopied] = useState(false);
  const chartRef = useRef<HTMLCanvasElement>(null);
  const chartInstance = useRef<Chart | null>(null);

  const calculate = useCallback(() => {
    const r = rate / 12 / 100;
    const n = tenure * 12;
    if (r === 0) {
      const emi = principal / n;
      setResults({ emi, totalPayment: principal, totalInterest: 0 });
      return { emi, totalPayment: principal, totalInterest: 0 };
    }
    const emi = (principal * r * Math.pow(1 + r, n)) / (Math.pow(1 + r, n) - 1);
    const totalPayment = emi * n;
    const totalInterest = totalPayment - principal;
    setResults({ emi, totalPayment, totalInterest });
    return { emi, totalPayment, totalInterest };
  }, [principal, rate, tenure]);

  useEffect(() => {
    const res = calculate();
    renderChart(principal, res.totalInterest);
  }, [principal, rate, tenure, calculate]);

  const renderChart = (p: number, interest: number) => {
    if (!chartRef.current) return;
    const isDark = document.documentElement.classList.contains('dark');
    if (chartInstance.current) chartInstance.current.destroy();
    chartInstance.current = new Chart(chartRef.current, {
      type: 'doughnut',
      data: {
        labels: ['Principal', 'Total Interest'],
        datasets: [{
          data: [Math.round(p), Math.round(interest)],
          backgroundColor: ['#1a9e72', '#e05b3a'],
          borderColor: isDark ? '#1e1c19' : '#ffffff',
          borderWidth: 3,
          hoverOffset: 8,
        }],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        cutout: '65%',
        plugins: {
          legend: { display: false },
          tooltip: {
            callbacks: { label: ctx => ` ${ctx.label}: ₹${(ctx.raw as number).toLocaleString('en-IN')}` },
            backgroundColor: isDark ? '#252320' : '#fff',
            titleColor: isDark ? '#f2ede8' : '#1a1714',
            bodyColor: isDark ? '#a09890' : '#5c5752',
            borderColor: isDark ? '#302d29' : '#e8e4de',
            borderWidth: 1,
            padding: 10,
          },
        },
        animation: { animateRotate: true, duration: 600 },
      },
    });
  };

  const reset = () => { setPrincipal(1000000); setRate(8.5); setTenure(20); };

  const copyResult = () => {
    const text = `EMI Calculator Result\nLoan Amount: ${fmt(principal)}\nInterest Rate: ${rate}% p.a.\nTenure: ${tenure} years\nMonthly EMI: ${fmt(results.emi)}\nTotal Interest: ${fmt(results.totalInterest)}\nTotal Payment: ${fmt(results.totalPayment)}`;
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const pct = principal > 0 ? Math.round((results.totalInterest / results.totalPayment) * 100) : 0;

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
      {/* Inputs */}
      <div className="rounded-2xl border p-6 space-y-7" style={{ background: 'var(--bg-card)', borderColor: 'var(--border)' }}>
        {/* Loan Amount */}
        <div>
          <div className="flex justify-between mb-2">
            <label className="text-sm font-semibold" style={{ color: 'var(--text-secondary)' }}>Loan Amount</label>
            <span className="text-sm font-bold" style={{ color: 'var(--emerald)' }}>{fmt(principal)}</span>
          </div>
          <input type="range" min={100000} max={10000000} step={50000} value={principal} onChange={e => setPrincipal(+e.target.value)} className="w-full" />
          <div className="flex justify-between text-xs mt-1" style={{ color: 'var(--text-muted)' }}>
            <span>₹1L</span><span>₹1Cr</span>
          </div>
          <input type="number" value={principal} onChange={e => setPrincipal(+e.target.value)} className="mt-3 w-full px-4 py-2.5 rounded-xl border text-sm font-medium" style={{ background: 'var(--bg-subtle)', borderColor: 'var(--border)', color: 'var(--text-primary)', outline: 'none' }} placeholder="Enter loan amount" />
        </div>

        {/* Interest Rate */}
        <div>
          <div className="flex justify-between mb-2">
            <label className="text-sm font-semibold" style={{ color: 'var(--text-secondary)' }}>Annual Interest Rate</label>
            <span className="text-sm font-bold" style={{ color: 'var(--amber)' }}>{rate.toFixed(1)}%</span>
          </div>
          <input type="range" min={1} max={30} step={0.1} value={rate} onChange={e => setRate(+e.target.value)} className="w-full" style={{ accentColor: 'var(--amber)' }} />
          <div className="flex justify-between text-xs mt-1" style={{ color: 'var(--text-muted)' }}>
            <span>1%</span><span>30%</span>
          </div>
          <input type="number" value={rate} step={0.1} min={1} max={30} onChange={e => setRate(+e.target.value)} className="mt-3 w-full px-4 py-2.5 rounded-xl border text-sm font-medium" style={{ background: 'var(--bg-subtle)', borderColor: 'var(--border)', color: 'var(--text-primary)', outline: 'none' }} />
        </div>

        {/* Tenure */}
        <div>
          <div className="flex justify-between mb-2">
            <label className="text-sm font-semibold" style={{ color: 'var(--text-secondary)' }}>Loan Tenure</label>
            <span className="text-sm font-bold" style={{ color: 'var(--coral)' }}>{tenure} {tenure === 1 ? 'Year' : 'Years'}</span>
          </div>
          <input type="range" min={1} max={30} step={1} value={tenure} onChange={e => setTenure(+e.target.value)} className="w-full" style={{ accentColor: 'var(--coral)' }} />
          <div className="flex justify-between text-xs mt-1" style={{ color: 'var(--text-muted)' }}>
            <span>1 Yr</span><span>30 Yrs</span>
          </div>
          <input type="number" value={tenure} min={1} max={30} onChange={e => setTenure(+e.target.value)} className="mt-3 w-full px-4 py-2.5 rounded-xl border text-sm font-medium" style={{ background: 'var(--bg-subtle)', borderColor: 'var(--border)', color: 'var(--text-primary)', outline: 'none' }} />
        </div>

        {/* Actions */}
        <div className="flex gap-3 pt-2">
          <button onClick={reset} className="flex items-center gap-2 px-4 py-2.5 rounded-xl border text-sm font-medium transition-colors" style={{ borderColor: 'var(--border)', color: 'var(--text-secondary)', background: 'var(--bg-subtle)' }}>
            <RotateCcw size={14} /> Reset
          </button>
          <button onClick={copyResult} className="flex items-center gap-2 px-4 py-2.5 rounded-xl border text-sm font-medium transition-colors" style={{ borderColor: 'var(--border)', color: 'var(--text-secondary)', background: 'var(--bg-subtle)' }}>
            {copied ? <Check size={14} /> : <Copy size={14} />}
            {copied ? 'Copied!' : 'Copy Result'}
          </button>
        </div>
      </div>

      {/* Results */}
      <div className="space-y-5">
        {/* EMI Result Card */}
        <div className="rounded-2xl p-6 text-center" style={{ background: 'linear-gradient(135deg, var(--emerald-light), var(--bg-card))', border: '1px solid var(--emerald-light)' }}>
          <p className="text-sm font-medium mb-1" style={{ color: 'var(--emerald)' }}>Monthly EMI</p>
          <p className="font-serif text-5xl font-bold mb-1" style={{ color: 'var(--text-primary)' }}>{fmt(results.emi)}</p>
          <p className="text-xs" style={{ color: 'var(--text-muted)' }}>per month for {tenure} years</p>
        </div>

        {/* Breakdown */}
        <div className="grid grid-cols-2 gap-4">
          <div className="rounded-xl p-4 text-center border" style={{ background: 'var(--bg-card)', borderColor: 'var(--border)' }}>
            <p className="text-xs font-medium mb-1" style={{ color: 'var(--text-muted)' }}>Principal</p>
            <p className="font-semibold text-lg" style={{ color: 'var(--emerald)' }}>{fmt(principal)}</p>
          </div>
          <div className="rounded-xl p-4 text-center border" style={{ background: 'var(--bg-card)', borderColor: 'var(--border)' }}>
            <p className="text-xs font-medium mb-1" style={{ color: 'var(--text-muted)' }}>Total Interest</p>
            <p className="font-semibold text-lg" style={{ color: 'var(--coral)' }}>{fmt(results.totalInterest)}</p>
          </div>
          <div className="rounded-xl p-4 text-center border col-span-2" style={{ background: 'var(--bg-card)', borderColor: 'var(--border)' }}>
            <p className="text-xs font-medium mb-1" style={{ color: 'var(--text-muted)' }}>Total Payment</p>
            <p className="font-semibold text-xl" style={{ color: 'var(--text-primary)' }}>{fmt(results.totalPayment)}</p>
            <p className="text-xs mt-1" style={{ color: 'var(--text-muted)' }}>Interest is {pct}% of total</p>
          </div>
        </div>

        {/* Chart */}
        <div className="rounded-2xl border p-5" style={{ background: 'var(--bg-card)', borderColor: 'var(--border)' }}>
          <p className="text-sm font-semibold mb-4 text-center" style={{ color: 'var(--text-secondary)' }}>Principal vs Interest</p>
          <div style={{ height: 200, position: 'relative' }}>
            <canvas ref={chartRef} />
          </div>
          <div className="flex justify-center gap-6 mt-4">
            <div className="flex items-center gap-2 text-xs" style={{ color: 'var(--text-secondary)' }}>
              <div className="w-3 h-3 rounded-full" style={{ background: '#1a9e72' }} />Principal
            </div>
            <div className="flex items-center gap-2 text-xs" style={{ color: 'var(--text-secondary)' }}>
              <div className="w-3 h-3 rounded-full" style={{ background: '#e05b3a' }} />Interest
            </div>
          </div>
        </div>

        {/* CTA */}
        <div className="rounded-xl p-4 flex items-center justify-between border" style={{ background: 'var(--bg-subtle)', borderColor: 'var(--border)' }}>
          <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>Planning to invest instead?</p>
          <Link href="/tools/sip-calculator" className="text-sm font-semibold px-4 py-2 rounded-lg transition-colors text-white" style={{ background: 'var(--plum)' }}>
            Try SIP Calculator →
          </Link>
        </div>
      </div>
    </div>
  );
}
