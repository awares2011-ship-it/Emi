'use client';
import { useEffect, useRef } from 'react';

interface AdBannerProps {
  slot: string;
  format?: 'auto' | 'rectangle' | 'horizontal' | 'vertical';
  className?: string;
  style?: React.CSSProperties;
}

declare global {
  interface Window { adsbygoogle: unknown[]; }
}

export default function AdBanner({ slot, format = 'auto', className = '', style }: AdBannerProps) {
  const adRef = useRef<HTMLModElement>(null);
  const initialized = useRef(false);

  useEffect(() => {
    if (initialized.current) return;
    initialized.current = true;
    try {
      (window.adsbygoogle = window.adsbygoogle || []).push({});
    } catch {}
  }, []);

  const CLIENT_ID = process.env.NEXT_PUBLIC_ADSENSE_CLIENT_ID;
  if (!CLIENT_ID) {
    // Dev placeholder
    return (
      <div className={`ad-placeholder flex items-center justify-center text-xs uppercase tracking-widest ${className}`} style={{ minHeight: 90, ...style }}>
        Advertisement
      </div>
    );
  }

  return (
    <ins
      ref={adRef}
      className={`adsbygoogle ${className}`}
      style={{ display: 'block', ...style }}
      data-ad-client={CLIENT_ID}
      data-ad-slot={slot}
      data-ad-format={format}
      data-full-width-responsive="true"
    />
  );
}
