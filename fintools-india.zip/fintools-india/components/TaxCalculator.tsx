'use client';
import { useState, useEffect } from 'react';
import { RotateCcw, Info } from 'lucide-react';

const fmt = (n: number) => '₹' + Math.round(n).toLocaleString('en-IN');
type Regime = 'new' | 'old';
type AgeGroup = 'below60' | '60to80' | 'above80';

// FY 2024-25 slabs
const NEW_SLABS = [
  { limit: 300000, rate: 0 }, { limit: 600000, rate: 5 }, { limit: 900000, rate: 10 },
  { limit: 1200000, rate: 15 }, { limit: 1500000, rate: 20 }, { limit: Infinity, rate: 30 },
];

const OLD_SLABS: Record<AgeGroup, { limit: number; rate: number }[]> = {
  below60: [
    { limit: 250000, rate: 0 }, { limit: 500000, rate: 5 }, { limit: 1000000, rate: 20 }, { limit: Infinity, rate: 30 },
  ],
  '60to80': [
    { limit: 300000, rate: 0 }, { limit: 500000, rate: 5 }, { limit: 1000000, rate: 20 }, { limit: Infinity, rate: 30 },
  ],
  above80: [
    { limit: 500000, rate: 0 }, { limit: 1000000, rate: 20 }, { limit: Infinity, rate: 30 },
  ],
};

function calcTax(income: number, slabs: { limit: number; rate: number }[]) {
  let tax = 0, prev = 0;
  for (const slab of slabs) {
    if (income <= prev) break;
    const taxable = Math.min(income, slab.limit) - prev;
    tax += (taxable * slab.rate) / 100;
    prev = slab.limit;
  }
  return tax;
}

export default function TaxCalculator() {
  const [income, setIncome] = useState(800000);
  const [regime, setRegime] = useState<Regime>('new');
  const [age, setAge] = useState<AgeGroup>('below60');
  const [deductions, setDeductions] = useState({ sec80c: 150000, hra: 0, nps: 0, lta: 0 });
  const [results, setResults] = useState({ tax: 0, cess: 0, total: 0, effectiveRate: 0, taxableIncome: 0 });

  useEffect(() => {
    let taxableIncome = income;
    if (regime === 'old') {
      const totalDed = Math.min(deductions.sec80c, 150000) + deductions.hra + Math.min(deductions.nps, 50000) + deductions.lta;
      const stdDed = 50000;
      taxableIncome = Math.max(0, income - totalDed - stdDed);
    } else {
      taxableIncome = Math.max(0, income - 75000); // Standard deduction for new regime
    }

    const slabs = regime === 'new' ? NEW_SLABS : OLD_SLABS[age];
    let tax = calcTax(taxableIncome, slabs);

    // Rebate u/s 87A
    if (regime === 'new' && taxableIncome <= 700000) tax = 0;
    if (regime === 'old' && taxableIncome <= 500000) tax = 0;

    // Surcharge (simplified)
    if (income > 5000000 && income <= 10000000) tax *= 1.10;
    else if (income > 10000000) tax *= 1.15;

    const cess = tax * 0.04;
    const total = tax + cess;
    const effectiveRate = income > 0 ? (total / income) * 100 : 0;
    setResults({ tax, cess, total, effectiveRate, taxableIncome });
  }, [income, regime, age, deductions]);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
      <div className="rounded-2xl border p-6 space-y-5" style={{ background: 'var(--bg-card)', borderColor: 'var(--border)' }}>
        <div>
          <label className="text-sm font-semibold block mb-3" style={{ color: 'var(--text-secondary)' }}>Tax Regime (FY 2024-25)</label>
          <div className="grid grid-cols-2 gap-2">
            {(['new', 'old'] as Regime[]).map(r => (
              <button key={r} onClick={() => setRegime(r)} className="py-2.5 px-4 rounded-xl border text-sm font-medium capitalize transition-colors" style={{ borderColor: regime === r ? 'var(--plum)' : 'var(--border)', background: regime === r ? 'var(--plum-light)' : 'var(--bg-subtle)', color: regime === r ? 'var(--plum)' : 'var(--text-secondary)' }}>
                {r === 'new' ? '🆕 New Regime' : '🏛 Old Regime'}
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="text-sm font-semibold block mb-2" style={{ color: 'var(--text-secondary)' }}>Annual Income (Gross)</label>
          <input type="number" value={income} onChange={e => setIncome(+e.target.value)} className="w-full px-4 py-3 rounded-xl border text-sm font-medium" style={{ background: 'var(--bg-subtle)', borderColor: 'var(--border)', color: 'var(--text-primary)', outline: 'none' }} />
          <input type="range" min={0} max={10000000} step={50000} value={income} onChange={e => setIncome(+e.target.value)} className="w-full mt-3" />
          <div className="flex justify-between text-xs mt-1" style={{ color: 'var(--text-muted)' }}><span>₹0</span><span>₹1 Cr</span></div>
        </div>

        {regime === 'old' && (
          <>
            <div>
              <label className="text-sm font-semibold block mb-2" style={{ color: 'var(--text-secondary)' }}>Age Group</label>
              <div className="grid grid-cols-3 gap-2">
                {([['below60', '< 60'], ['60to80', '60–80'], ['above80', '> 80']] as [AgeGroup, string][]).map(([v, l]) => (
                  <button key={v} onClick={() => setAge(v)} className="py-2 rounded-xl border text-xs font-medium transition-colors" style={{ borderColor: age === v ? 'var(--coral)' : 'var(--border)', background: age === v ? 'var(--coral-light)' : 'var(--bg-subtle)', color: age === v ? 'var(--coral)' : 'var(--text-secondary)' }}>
                    {l}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-3">
              <p className="text-sm font-semibold" style={{ color: 'var(--text-secondary)' }}>Deductions (Old Regime)</p>
              {[
                { key: 'sec80c', label: 'Sec 80C (max ₹1.5L)', max: 150000 },
                { key: 'hra', label: 'HRA Exemption', max: 500000 },
                { key: 'nps', label: 'NPS 80CCD(1B) (max ₹50K)', max: 50000 },
                { key: 'lta', label: 'LTA / Other', max: 200000 },
              ].map(d => (
                <div key={d.key} className="flex items-center gap-3">
                  <span className="text-xs w-36 shrink-0" style={{ color: 'var(--text-muted)' }}>{d.label}</span>
                  <input type="number" value={deductions[d.key as keyof typeof deductions]} max={d.max} onChange={e => setDeductions(prev => ({ ...prev, [d.key]: +e.target.value }))} className="flex-1 px-3 py-2 rounded-lg border text-xs font-medium" style={{ background: 'var(--bg-subtle)', borderColor: 'var(--border)', color: 'var(--text-primary)', outline: 'none' }} />
                </div>
              ))}
            </div>
          </>
        )}

        <button onClick={() => { setIncome(800000); setRegime('new'); setAge('below60'); setDeductions({ sec80c: 150000, hra: 0, nps: 0, lta: 0 }); }} className="flex items-center gap-2 px-4 py-2.5 rounded-xl border text-sm font-medium" style={{ borderColor: 'var(--border)', color: 'var(--text-secondary)', background: 'var(--bg-subtle)' }}>
          <RotateCcw size={14} /> Reset
        </button>
      </div>

      <div className="space-y-4">
        <div className="rounded-2xl p-6 text-center" style={{ background: 'linear-gradient(135deg, var(--coral-light), var(--bg-card))', border: '1px solid var(--coral-light)' }}>
          <p className="text-sm font-medium mb-1" style={{ color: 'var(--coral)' }}>Total Tax Payable</p>
          <p className="font-serif text-5xl font-bold mb-1" style={{ color: 'var(--text-primary)' }}>{fmt(results.total)}</p>
          <p className="text-xs" style={{ color: 'var(--text-muted)' }}>Effective rate: {results.effectiveRate.toFixed(2)}%</p>
        </div>

        <div className="rounded-2xl border p-5 space-y-2" style={{ background: 'var(--bg-card)', borderColor: 'var(--border)' }}>
          {[
            { label: 'Gross Income', value: fmt(income), color: 'var(--text-primary)' },
            { label: 'Taxable Income', value: fmt(results.taxableIncome), color: 'var(--text-secondary)' },
            { label: 'Income Tax', value: fmt(results.tax), color: 'var(--coral)' },
            { label: 'Health & Education Cess (4%)', value: fmt(results.cess), color: 'var(--amber)' },
            { label: 'Total Tax', value: fmt(results.total), color: 'var(--coral)' },
            { label: 'In-hand Income', value: fmt(income - results.total), color: 'var(--emerald)' },
          ].map(r => (
            <div key={r.label} className="flex justify-between py-2 border-b last:border-0 last:font-bold" style={{ borderColor: 'var(--border)' }}>
              <span className="text-sm" style={{ color: 'var(--text-secondary)' }}>{r.label}</span>
              <span className="text-sm font-semibold" style={{ color: r.color }}>{r.value}</span>
            </div>
          ))}
        </div>

        <div className="rounded-xl p-4 flex gap-3 border" style={{ background: 'var(--bg-subtle)', borderColor: 'var(--border)' }}>
          <Info size={16} style={{ color: 'var(--amber)', flexShrink: 0, marginTop: 2 }} />
          <p className="text-xs" style={{ color: 'var(--text-muted)' }}>
            Calculated for FY 2024-25 (AY 2025-26). Rebate u/s 87A applied. Does not include surcharge above ₹50L income or special income (LTCG/STCG). Consult a CA for filing.
          </p>
        </div>
      </div>
    </div>
  );
}
