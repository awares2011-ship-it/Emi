import Link from 'next/link';
import { Clock, ArrowRight } from 'lucide-react';
import type { BlogPost } from '@/lib/blog';

const categoryColors: Record<string, { bg: string; color: string }> = {
  emi:  { bg: 'var(--emerald-light)', color: 'var(--emerald)' },
  sip:  { bg: 'var(--plum-light)',    color: 'var(--plum)' },
  tax:  { bg: 'var(--amber-light)',   color: 'var(--amber)' },
  fd:   { bg: 'var(--coral-light)',   color: 'var(--coral)' },
  gst:  { bg: 'var(--emerald-light)', color: 'var(--emerald)' },
  general: { bg: 'var(--bg-subtle)', color: 'var(--text-secondary)' },
};

export default function BlogCard({ post }: { post: BlogPost }) {
  const cat = categoryColors[post.category] || categoryColors.general;
  const date = post.createdAt instanceof Date
    ? post.createdAt
    : (post.createdAt as { toDate: () => Date }).toDate?.() ?? new Date();

  return (
    <Link href={`/blog/${post.slug}`} className="group block rounded-2xl border overflow-hidden transition-all hover:-translate-y-1" style={{ background: 'var(--bg-card)', borderColor: 'var(--border)', boxShadow: 'var(--shadow-sm)' }}
      onMouseEnter={e => (e.currentTarget.style.boxShadow = 'var(--shadow-md)')}
      onMouseLeave={e => (e.currentTarget.style.boxShadow = 'var(--shadow-sm)')}>
      <div className="p-6">
        <div className="flex items-center justify-between mb-3">
          <span className="text-xs font-semibold uppercase tracking-wider px-3 py-1 rounded-full" style={{ background: cat.bg, color: cat.color }}>
            {post.category}
          </span>
          <div className="flex items-center gap-1 text-xs" style={{ color: 'var(--text-muted)' }}>
            <Clock size={11} />
            {post.readTime ?? 5} min read
          </div>
        </div>
        <h3 className="font-serif font-semibold text-lg leading-snug mb-2 group-hover:underline decoration-1 underline-offset-2" style={{ color: 'var(--text-primary)' }}>
          {post.title}
        </h3>
        <p className="text-sm leading-relaxed mb-4" style={{ color: 'var(--text-secondary)' }}>
          {post.excerpt}
        </p>
        <div className="flex items-center justify-between">
          <span className="text-xs" style={{ color: 'var(--text-muted)' }}>
            {date.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}
          </span>
          <span className="flex items-center gap-1 text-xs font-medium" style={{ color: 'var(--emerald)' }}>
            Read more <ArrowRight size={12} className="group-hover:translate-x-1 transition-transform" />
          </span>
        </div>
      </div>
    </Link>
  );
}
