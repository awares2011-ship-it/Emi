'use client';
import Link from 'next/link';
import { useState } from 'react';
import { useTheme } from './ThemeProvider';
import { Menu, X, Sun, Moon, Calculator, BookOpen, ChevronDown } from 'lucide-react';

const tools = [
  { href: '/tools/emi-calculator', label: 'EMI Calculator' },
  { href: '/tools/sip-calculator', label: 'SIP Calculator' },
  { href: '/tools/fd-calculator', label: 'FD Calculator' },
  { href: '/tools/gst-calculator', label: 'GST Calculator' },
  { href: '/tools/income-tax-calculator', label: 'Tax Calculator' },
];

export default function Navbar() {
  const { theme, toggle } = useTheme();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [toolsOpen, setToolsOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 border-b" style={{ background: 'rgba(250,249,246,0.92)', backdropFilter: 'blur(16px)', borderColor: 'var(--border)' }}>
      <style>{`.dark header { background: rgba(20,18,16,0.92) !important; }`}</style>
      <div className="max-w-6xl mx-auto px-4">
        <div className="flex items-center justify-between h-16 gap-4">

          {/* Logo */}
          <Link href="/" className="flex items-center gap-2.5 font-serif font-bold text-xl" style={{ color: 'var(--text-primary)' }}>
            <div className="w-9 h-9 rounded-lg flex items-center justify-center text-white text-lg" style={{ background: 'linear-gradient(135deg, #1a9e72, #e8920a)' }}>
              ₹
            </div>
            <span>FinTools <span style={{ color: 'var(--emerald)' }}>India</span></span>
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-1">
            {/* Tools Dropdown */}
            <div className="relative" onMouseEnter={() => setToolsOpen(true)} onMouseLeave={() => setToolsOpen(false)}>
              <button className="flex items-center gap-1 px-3 py-2 rounded-lg text-sm font-medium transition-colors hover:bg-opacity-10" style={{ color: 'var(--text-secondary)' }}>
                <Calculator size={15} />
                Tools
                <ChevronDown size={13} className={`transition-transform ${toolsOpen ? 'rotate-180' : ''}`} />
              </button>
              {toolsOpen && (
                <div className="absolute top-full left-0 w-52 rounded-xl shadow-xl border py-2 mt-1" style={{ background: 'var(--bg-card)', borderColor: 'var(--border)' }}>
                  {tools.map(t => (
                    <Link key={t.href} href={t.href} className="block px-4 py-2.5 text-sm hover:bg-opacity-50 transition-colors" style={{ color: 'var(--text-secondary)' }}
                      onMouseEnter={e => (e.currentTarget.style.background = 'var(--bg-subtle)')}
                      onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}>
                      {t.label}
                    </Link>
                  ))}
                </div>
              )}
            </div>

            <Link href="/blog" className="flex items-center gap-1 px-3 py-2 rounded-lg text-sm font-medium transition-colors" style={{ color: 'var(--text-secondary)' }}>
              <BookOpen size={15} />
              Blog
            </Link>
            <Link href="/about" className="px-3 py-2 rounded-lg text-sm font-medium" style={{ color: 'var(--text-secondary)' }}>About</Link>
            <Link href="/contact" className="px-3 py-2 rounded-lg text-sm font-medium" style={{ color: 'var(--text-secondary)' }}>Contact</Link>
          </nav>

          {/* Right Actions */}
          <div className="flex items-center gap-2">
            <button onClick={toggle} className="p-2 rounded-lg transition-colors" style={{ color: 'var(--text-secondary)', background: 'var(--bg-subtle)' }} aria-label="Toggle theme">
              {theme === 'dark' ? <Sun size={17} /> : <Moon size={17} />}
            </button>
            <button className="md:hidden p-2 rounded-lg" style={{ color: 'var(--text-secondary)', background: 'var(--bg-subtle)' }} onClick={() => setMobileOpen(!mobileOpen)} aria-label="Menu">
              {mobileOpen ? <X size={18} /> : <Menu size={18} />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {mobileOpen && (
          <div className="md:hidden border-t py-4 space-y-1" style={{ borderColor: 'var(--border)' }}>
            <p className="px-3 py-1 text-xs font-semibold uppercase tracking-wider" style={{ color: 'var(--text-muted)' }}>Calculators</p>
            {tools.map(t => (
              <Link key={t.href} href={t.href} className="block px-3 py-2.5 rounded-lg text-sm" style={{ color: 'var(--text-secondary)' }} onClick={() => setMobileOpen(false)}>{t.label}</Link>
            ))}
            <div className="border-t my-2" style={{ borderColor: 'var(--border)' }} />
            <Link href="/blog" className="block px-3 py-2.5 rounded-lg text-sm" style={{ color: 'var(--text-secondary)' }} onClick={() => setMobileOpen(false)}>Blog</Link>
            <Link href="/about" className="block px-3 py-2.5 rounded-lg text-sm" style={{ color: 'var(--text-secondary)' }} onClick={() => setMobileOpen(false)}>About</Link>
            <Link href="/contact" className="block px-3 py-2.5 rounded-lg text-sm" style={{ color: 'var(--text-secondary)' }} onClick={() => setMobileOpen(false)}>Contact</Link>
          </div>
        )}
      </div>
    </header>
  );
}
