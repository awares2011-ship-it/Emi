import Link from 'next/link';

const tools = [
  { href: '/tools/emi-calculator', label: 'EMI Calculator' },
  { href: '/tools/sip-calculator', label: 'SIP Calculator' },
  { href: '/tools/fd-calculator', label: 'FD Calculator' },
  { href: '/tools/gst-calculator', label: 'GST Calculator' },
  { href: '/tools/income-tax-calculator', label: 'Tax Calculator' },
];

const legal = [
  { href: '/about', label: 'About Us' },
  { href: '/contact', label: 'Contact Us' },
  { href: '/privacy-policy', label: 'Privacy Policy' },
  { href: '/terms', label: 'Terms & Conditions' },
  { href: '/disclaimer', label: 'Disclaimer' },
];

export default function Footer() {
  return (
    <footer className="border-t mt-20" style={{ borderColor: 'var(--border)', background: 'var(--bg-subtle)' }}>
      <div className="max-w-6xl mx-auto px-4 py-14">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-10 mb-10">
          {/* Brand */}
          <div className="md:col-span-1">
            <div className="flex items-center gap-2 mb-3">
              <div className="w-8 h-8 rounded-lg flex items-center justify-center text-white font-bold" style={{ background: 'linear-gradient(135deg, #1a9e72, #e8920a)' }}>₹</div>
              <span className="font-serif font-bold text-lg" style={{ color: 'var(--text-primary)' }}>FinTools India</span>
            </div>
            <p className="text-sm leading-relaxed" style={{ color: 'var(--text-muted)' }}>
              Free financial calculators for Indian investors. EMI, SIP, FD, GST & Tax tools built for India.
            </p>
          </div>

          {/* Calculators */}
          <div>
            <h4 className="font-semibold text-sm mb-4 uppercase tracking-wider" style={{ color: 'var(--text-secondary)' }}>Calculators</h4>
            <ul className="space-y-2">
              {tools.map(t => (
                <li key={t.href}>
                  <Link href={t.href} className="text-sm transition-colors hover:underline" style={{ color: 'var(--text-muted)' }}>{t.label}</Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Blog */}
          <div>
            <h4 className="font-semibold text-sm mb-4 uppercase tracking-wider" style={{ color: 'var(--text-secondary)' }}>Resources</h4>
            <ul className="space-y-2">
              <li><Link href="/blog" className="text-sm" style={{ color: 'var(--text-muted)' }}>Finance Blog</Link></li>
              <li><Link href="/blog?category=emi" className="text-sm" style={{ color: 'var(--text-muted)' }}>EMI Guides</Link></li>
              <li><Link href="/blog?category=sip" className="text-sm" style={{ color: 'var(--text-muted)' }}>SIP Insights</Link></li>
              <li><Link href="/blog?category=tax" className="text-sm" style={{ color: 'var(--text-muted)' }}>Tax Tips</Link></li>
            </ul>
          </div>

          {/* Legal */}
          <div>
            <h4 className="font-semibold text-sm mb-4 uppercase tracking-wider" style={{ color: 'var(--text-secondary)' }}>Company</h4>
            <ul className="space-y-2">
              {legal.map(l => (
                <li key={l.href}>
                  <Link href={l.href} className="text-sm" style={{ color: 'var(--text-muted)' }}>{l.label}</Link>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="border-t pt-6 flex flex-col md:flex-row justify-between items-center gap-3" style={{ borderColor: 'var(--border)' }}>
          <p className="text-xs" style={{ color: 'var(--text-muted)' }}>
            © {new Date().getFullYear()} FinTools India. All rights reserved.
          </p>
          <p className="text-xs" style={{ color: 'var(--text-muted)' }}>
            For informational purposes only. Not financial advice. Consult a SEBI-registered advisor.
          </p>
        </div>
      </div>
    </footer>
  );
}
