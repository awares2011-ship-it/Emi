'use client';
import { useState, useEffect, useRef, useCallback } from 'react';
import { Chart, LineElement, PointElement, LinearScale, CategoryScale, Tooltip, Legend, LineController, Filler } from 'chart.js';
import Link from 'next/link';
import { RotateCcw, Copy, Check, TrendingUp } from 'lucide-react';

Chart.register(LineElement, PointElement, LinearScale, CategoryScale, Tooltip, Legend, LineController, Filler);

const fmt = (n: number) => '₹' + Math.round(n).toLocaleString('en-IN');
const fmtCompact = (n: number) => {
  if (n >= 1e7) return '₹' + (n / 1e7).toFixed(2) + ' Cr';
  if (n >= 1e5) return '₹' + (n / 1e5).toFixed(2) + ' L';
  return '₹' + Math.round(n).toLocaleString('en-IN');
};

export default function SipCalculator() {
  const [monthly, setMonthly] = useState(10000);
  const [rate, setRate] = useState(12);
  const [years, setYears] = useState(10);
  const [results, setResults] = useState({ totalValue: 0, totalInvested: 0, estimatedReturns: 0 });
  const [copied, setCopied] = useState(false);
  const chartRef = useRef<HTMLCanvasElement>(null);
  const chartInstance = useRef<Chart | null>(null);

  const calculate = useCallback(() => {
    const r = rate / 12 / 100;
    const n = years * 12;
    const totalValue = monthly * ((Math.pow(1 + r, n) - 1) / r) * (1 + r);
    const totalInvested = monthly * n;
    const estimatedReturns = totalValue - totalInvested;
    setResults({ totalValue, totalInvested, estimatedReturns });
    return { totalValue, totalInvested, estimatedReturns, r, n };
  }, [monthly, rate, years]);

  useEffect(() => {
    const res = calculate();
    renderChart(res.r, res.n);
  }, [monthly, rate, years, calculate]);

  const renderChart = (r: number, n: number) => {
    if (!chartRef.current) return;
    const isDark = document.documentElement.classList.contains('dark');
    const labels: string[] = [], investedData: number[] = [], totalData: number[] = [];
    for (let y = 1; y <= years; y++) {
      const months = y * 12;
      const tv = monthly * ((Math.pow(1 + r, months) - 1) / r) * (1 + r);
      labels.push('Yr ' + y);
      investedData.push(Math.round(monthly * months));
      totalData.push(Math.round(tv));
    }
    if (chartInstance.current) chartInstance.current.destroy();
    chartInstance.current = new Chart(chartRef.current, {
      type: 'line',
      data: {
        labels,
        datasets: [
          { label: 'Total Value', data: totalData, borderColor: '#8b3dba', backgroundColor: 'rgba(139,61,186,0.12)', borderWidth: 2.5, fill: true, tension: 0.4, pointRadius: 0, pointHoverRadius: 6 },
          { label: 'Invested', data: investedData, borderColor: '#e8920a', backgroundColor: 'rgba(232,146,10,0.08)', borderWidth: 2, fill: true, tension: 0.4, pointRadius: 0, pointHoverRadius: 6 },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        interaction: { mode: 'index', intersect: false },
        scales: {
          x: { grid: { color: isDark ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.05)' }, ticks: { color: isDark ? '#6b6560' : '#9c9690', font: { size: 10 }, maxTicksLimit: 10 } },
          y: { grid: { color: isDark ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.05)' }, ticks: { color: isDark ? '#6b6560' : '#9c9690', font: { size: 10 }, callback: v => fmtCompact(v as number) } },
        },
        plugins: {
          legend: { display: false },
          tooltip: {
            backgroundColor: isDark ? '#252320' : '#fff',
            titleColor: isDark ? '#f2ede8' : '#1a1714',
            bodyColor: isDark ? '#a09890' : '#5c5752',
            borderColor: isDark ? '#302d29' : '#e8e4de',
            borderWidth: 1,
            padding: 10,
            callbacks: { label: ctx => ` ${ctx.dataset.label}: ${fmtCompact(ctx.raw as number)}` },
          },
        },
        animation: { duration: 600 },
      },
    });
  };

  const reset = () => { setMonthly(10000); setRate(12); setYears(10); };
  const copyResult = () => {
    const text = `SIP Calculator Result\nMonthly SIP: ${fmt(monthly)}\nExpected Return: ${rate}% p.a.\nTime Period: ${years} years\nTotal Invested: ${fmt(results.totalInvested)}\nEstimated Returns: ${fmt(results.estimatedReturns)}\nTotal Value: ${fmt(results.totalValue)}`;
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const xirr = results.totalInvested > 0 ? ((results.totalValue / results.totalInvested - 1) * 100).toFixed(1) : '0';

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
      {/* Inputs */}
      <div className="rounded-2xl border p-6 space-y-7" style={{ background: 'var(--bg-card)', borderColor: 'var(--border)' }}>
        {/* Monthly SIP */}
        <div>
          <div className="flex justify-between mb-2">
            <label className="text-sm font-semibold" style={{ color: 'var(--text-secondary)' }}>Monthly SIP Amount</label>
            <span className="text-sm font-bold" style={{ color: 'var(--plum)' }}>{fmt(monthly)}</span>
          </div>
          <input type="range" min={500} max={100000} step={500} value={monthly} onChange={e => setMonthly(+e.target.value)} className="w-full" style={{ accentColor: 'var(--plum)' }} />
          <div className="flex justify-between text-xs mt-1" style={{ color: 'var(--text-muted)' }}><span>₹500</span><span>₹1L</span></div>
          <input type="number" value={monthly} onChange={e => setMonthly(+e.target.value)} className="mt-3 w-full px-4 py-2.5 rounded-xl border text-sm font-medium" style={{ background: 'var(--bg-subtle)', borderColor: 'var(--border)', color: 'var(--text-primary)', outline: 'none' }} />
        </div>

        {/* Return Rate */}
        <div>
          <div className="flex justify-between mb-2">
            <label className="text-sm font-semibold" style={{ color: 'var(--text-secondary)' }}>Expected Annual Return</label>
            <span className="text-sm font-bold" style={{ color: 'var(--emerald)' }}>{rate.toFixed(1)}%</span>
          </div>
          <input type="range" min={1} max={30} step={0.5} value={rate} onChange={e => setRate(+e.target.value)} className="w-full" style={{ accentColor: 'var(--emerald)' }} />
          <div className="flex justify-between text-xs mt-1" style={{ color: 'var(--text-muted)' }}><span>1%</span><span>30%</span></div>
          <input type="number" value={rate} step={0.5} onChange={e => setRate(+e.target.value)} className="mt-3 w-full px-4 py-2.5 rounded-xl border text-sm font-medium" style={{ background: 'var(--bg-subtle)', borderColor: 'var(--border)', color: 'var(--text-primary)', outline: 'none' }} />
        </div>

        {/* Time Period */}
        <div>
          <div className="flex justify-between mb-2">
            <label className="text-sm font-semibold" style={{ color: 'var(--text-secondary)' }}>Time Period</label>
            <span className="text-sm font-bold" style={{ color: 'var(--amber)' }}>{years} {years === 1 ? 'Year' : 'Years'}</span>
          </div>
          <input type="range" min={1} max={40} step={1} value={years} onChange={e => setYears(+e.target.value)} className="w-full" style={{ accentColor: 'var(--amber)' }} />
          <div className="flex justify-between text-xs mt-1" style={{ color: 'var(--text-muted)' }}><span>1 Yr</span><span>40 Yrs</span></div>
          <input type="number" value={years} min={1} max={40} onChange={e => setYears(+e.target.value)} className="mt-3 w-full px-4 py-2.5 rounded-xl border text-sm font-medium" style={{ background: 'var(--bg-subtle)', borderColor: 'var(--border)', color: 'var(--text-primary)', outline: 'none' }} />
        </div>

        <div className="flex gap-3 pt-2">
          <button onClick={reset} className="flex items-center gap-2 px-4 py-2.5 rounded-xl border text-sm font-medium" style={{ borderColor: 'var(--border)', color: 'var(--text-secondary)', background: 'var(--bg-subtle)' }}>
            <RotateCcw size={14} /> Reset
          </button>
          <button onClick={copyResult} className="flex items-center gap-2 px-4 py-2.5 rounded-xl border text-sm font-medium" style={{ borderColor: 'var(--border)', color: 'var(--text-secondary)', background: 'var(--bg-subtle)' }}>
            {copied ? <Check size={14} /> : <Copy size={14} />}
            {copied ? 'Copied!' : 'Copy Result'}
          </button>
        </div>
      </div>

      {/* Results */}
      <div className="space-y-5">
        <div className="rounded-2xl p-6 text-center" style={{ background: 'linear-gradient(135deg, var(--plum-light), var(--bg-card))', border: '1px solid var(--plum-light)' }}>
          <p className="text-sm font-medium mb-1" style={{ color: 'var(--plum)' }}>Estimated Corpus</p>
          <p className="font-serif text-5xl font-bold mb-1" style={{ color: 'var(--text-primary)' }}>{fmtCompact(results.totalValue)}</p>
          <div className="flex items-center justify-center gap-1 text-xs" style={{ color: 'var(--text-muted)' }}>
            <TrendingUp size={12} style={{ color: 'var(--emerald)' }} />
            {xirr}% total gain
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="rounded-xl p-4 text-center border" style={{ background: 'var(--bg-card)', borderColor: 'var(--border)' }}>
            <p className="text-xs font-medium mb-1" style={{ color: 'var(--text-muted)' }}>Total Invested</p>
            <p className="font-semibold text-lg" style={{ color: 'var(--amber)' }}>{fmtCompact(results.totalInvested)}</p>
          </div>
          <div className="rounded-xl p-4 text-center border" style={{ background: 'var(--bg-card)', borderColor: 'var(--border)' }}>
            <p className="text-xs font-medium mb-1" style={{ color: 'var(--text-muted)' }}>Est. Returns</p>
            <p className="font-semibold text-lg" style={{ color: 'var(--emerald)' }}>{fmtCompact(results.estimatedReturns)}</p>
          </div>
        </div>

        <div className="rounded-2xl border p-5" style={{ background: 'var(--bg-card)', borderColor: 'var(--border)' }}>
          <p className="text-sm font-semibold mb-4 text-center" style={{ color: 'var(--text-secondary)' }}>Growth Over Time</p>
          <div style={{ height: 200, position: 'relative' }}>
            <canvas ref={chartRef} />
          </div>
          <div className="flex justify-center gap-6 mt-4">
            <div className="flex items-center gap-2 text-xs" style={{ color: 'var(--text-secondary)' }}><div className="w-3 h-3 rounded-full" style={{ background: '#8b3dba' }} />Total Value</div>
            <div className="flex items-center gap-2 text-xs" style={{ color: 'var(--text-secondary)' }}><div className="w-3 h-3 rounded-full" style={{ background: '#e8920a' }} />Invested</div>
          </div>
        </div>

        <div className="rounded-xl p-4 flex items-center justify-between border" style={{ background: 'var(--bg-subtle)', borderColor: 'var(--border)' }}>
          <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>Have a loan? Check EMI</p>
          <Link href="/tools/emi-calculator" className="text-sm font-semibold px-4 py-2 rounded-lg text-white" style={{ background: 'var(--emerald)' }}>
            EMI Calculator →
          </Link>
        </div>
      </div>
    </div>
  );
}
