'use client';
import { useState, useCallback, useEffect } from 'react';
import Link from 'next/link';
import { RotateCcw } from 'lucide-react';

const fmt = (n: number) => '₹' + Math.round(n).toLocaleString('en-IN');
type CompoundFreq = 'monthly' | 'quarterly' | 'annually';

export default function FDCalculator() {
  const [principal, setPrincipal] = useState(100000);
  const [rate, setRate] = useState(7.0);
  const [years, setYears] = useState(3);
  const [freq, setFreq] = useState<CompoundFreq>('quarterly');
  const [results, setResults] = useState({ maturity: 0, interest: 0 });

  const freqMap: Record<CompoundFreq, number> = { monthly: 12, quarterly: 4, annually: 1 };

  const calculate = useCallback(() => {
    const n = freqMap[freq];
    const t = years;
    const r = rate / 100;
    const maturity = principal * Math.pow(1 + r / n, n * t);
    const interest = maturity - principal;
    setResults({ maturity, interest });
  }, [principal, rate, years, freq]);

  useEffect(() => { calculate(); }, [calculate]);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
      <div className="rounded-2xl border p-6 space-y-6" style={{ background: 'var(--bg-card)', borderColor: 'var(--border)' }}>
        <div>
          <div className="flex justify-between mb-2">
            <label className="text-sm font-semibold" style={{ color: 'var(--text-secondary)' }}>Principal Amount</label>
            <span className="text-sm font-bold" style={{ color: 'var(--amber)' }}>{fmt(principal)}</span>
          </div>
          <input type="range" min={10000} max={10000000} step={10000} value={principal} onChange={e => setPrincipal(+e.target.value)} className="w-full" style={{ accentColor: 'var(--amber)' }} />
          <input type="number" value={principal} onChange={e => setPrincipal(+e.target.value)} className="mt-3 w-full px-4 py-2.5 rounded-xl border text-sm font-medium" style={{ background: 'var(--bg-subtle)', borderColor: 'var(--border)', color: 'var(--text-primary)', outline: 'none' }} />
        </div>

        <div>
          <div className="flex justify-between mb-2">
            <label className="text-sm font-semibold" style={{ color: 'var(--text-secondary)' }}>Annual Interest Rate</label>
            <span className="text-sm font-bold" style={{ color: 'var(--emerald)' }}>{rate.toFixed(1)}%</span>
          </div>
          <input type="range" min={1} max={15} step={0.1} value={rate} onChange={e => setRate(+e.target.value)} className="w-full" style={{ accentColor: 'var(--emerald)' }} />
          <input type="number" value={rate} step={0.1} onChange={e => setRate(+e.target.value)} className="mt-3 w-full px-4 py-2.5 rounded-xl border text-sm font-medium" style={{ background: 'var(--bg-subtle)', borderColor: 'var(--border)', color: 'var(--text-primary)', outline: 'none' }} />
        </div>

        <div>
          <div className="flex justify-between mb-2">
            <label className="text-sm font-semibold" style={{ color: 'var(--text-secondary)' }}>Tenure (Years)</label>
            <span className="text-sm font-bold" style={{ color: 'var(--coral)' }}>{years} Yrs</span>
          </div>
          <input type="range" min={1} max={10} step={1} value={years} onChange={e => setYears(+e.target.value)} className="w-full" style={{ accentColor: 'var(--coral)' }} />
          <input type="number" value={years} min={1} max={10} onChange={e => setYears(+e.target.value)} className="mt-3 w-full px-4 py-2.5 rounded-xl border text-sm font-medium" style={{ background: 'var(--bg-subtle)', borderColor: 'var(--border)', color: 'var(--text-primary)', outline: 'none' }} />
        </div>

        <div>
          <label className="text-sm font-semibold block mb-2" style={{ color: 'var(--text-secondary)' }}>Compounding Frequency</label>
          <div className="grid grid-cols-3 gap-2">
            {(['monthly', 'quarterly', 'annually'] as CompoundFreq[]).map(f => (
              <button key={f} onClick={() => setFreq(f)} className="py-2 px-3 rounded-xl border text-sm font-medium capitalize transition-colors" style={{ borderColor: freq === f ? 'var(--emerald)' : 'var(--border)', background: freq === f ? 'var(--emerald-light)' : 'var(--bg-subtle)', color: freq === f ? 'var(--emerald)' : 'var(--text-secondary)' }}>
                {f}
              </button>
            ))}
          </div>
        </div>

        <button onClick={() => { setPrincipal(100000); setRate(7); setYears(3); setFreq('quarterly'); }} className="flex items-center gap-2 px-4 py-2.5 rounded-xl border text-sm font-medium" style={{ borderColor: 'var(--border)', color: 'var(--text-secondary)', background: 'var(--bg-subtle)' }}>
          <RotateCcw size={14} /> Reset
        </button>
      </div>

      <div className="space-y-5">
        <div className="rounded-2xl p-6 text-center" style={{ background: 'linear-gradient(135deg, var(--amber-light), var(--bg-card))', border: '1px solid var(--amber-light)' }}>
          <p className="text-sm font-medium mb-1" style={{ color: 'var(--amber)' }}>Maturity Amount</p>
          <p className="font-serif text-5xl font-bold mb-1" style={{ color: 'var(--text-primary)' }}>{fmt(results.maturity)}</p>
          <p className="text-xs" style={{ color: 'var(--text-muted)' }}>After {years} years at {rate}% p.a.</p>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="rounded-xl p-4 text-center border" style={{ background: 'var(--bg-card)', borderColor: 'var(--border)' }}>
            <p className="text-xs font-medium mb-1" style={{ color: 'var(--text-muted)' }}>Principal</p>
            <p className="font-semibold text-lg" style={{ color: 'var(--amber)' }}>{fmt(principal)}</p>
          </div>
          <div className="rounded-xl p-4 text-center border" style={{ background: 'var(--bg-card)', borderColor: 'var(--border)' }}>
            <p className="text-xs font-medium mb-1" style={{ color: 'var(--text-muted)' }}>Interest Earned</p>
            <p className="font-semibold text-lg" style={{ color: 'var(--emerald)' }}>{fmt(results.interest)}</p>
          </div>
        </div>

        <div className="rounded-xl p-4 border" style={{ background: 'var(--bg-subtle)', borderColor: 'var(--border)' }}>
          <p className="text-sm font-semibold mb-3" style={{ color: 'var(--text-secondary)' }}>Current FD Rates (Indicative)</p>
          {[['SBI', '6.80%'], ['HDFC Bank', '7.00%'], ['ICICI Bank', '7.00%'], ['Axis Bank', '7.10%']].map(([bank, r]) => (
            <div key={bank} className="flex justify-between items-center py-1.5 text-sm border-b last:border-0" style={{ borderColor: 'var(--border)', color: 'var(--text-secondary)' }}>
              <span>{bank}</span><span className="font-semibold" style={{ color: 'var(--emerald)' }}>{r}</span>
            </div>
          ))}
          <p className="text-xs mt-2" style={{ color: 'var(--text-muted)' }}>*Rates change. Verify with your bank.</p>
        </div>

        <div className="rounded-xl p-4 flex items-center justify-between border" style={{ background: 'var(--bg-subtle)', borderColor: 'var(--border)' }}>
          <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>Compare with SIP returns</p>
          <Link href="/tools/sip-calculator" className="text-sm font-semibold px-4 py-2 rounded-lg text-white" style={{ background: 'var(--plum)' }}>
            SIP Calculator →
          </Link>
        </div>
      </div>
    </div>
  );
}
