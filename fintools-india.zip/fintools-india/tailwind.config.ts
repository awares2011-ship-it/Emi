import type { Config } from 'tailwindcss'

const config: Config = {
  content: [
    './pages/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
    './app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        emerald: {
          DEFAULT: '#1a9e72',
          light: '#d4f0e7',
          dark: '#0f3326',
        },
        amber: {
          DEFAULT: '#e8920a',
          light: '#fef3dc',
          dark: '#2e200a',
        },
        coral: {
          DEFAULT: '#e05b3a',
          light: '#fde9e3',
          dark: '#2e1410',
        },
        plum: {
          DEFAULT: '#8b3dba',
          light: '#f0e4fa',
          dark: '#21103a',
        },
      },
      fontFamily: {
        sans: ['Outfit', 'system-ui', 'sans-serif'],
        serif: ['Cormorant Garamond', 'Georgia', 'serif'],
      },
      animation: {
        'fade-in': 'fadeIn 0.5s ease-out',
        'slide-up': 'slideUp 0.4s ease-out',
        'count': 'countAnim 0.5s ease-out',
      },
      keyframes: {
        fadeIn: { from: { opacity: '0' }, to: { opacity: '1' } },
        slideUp: { from: { opacity: '0', transform: 'translateY(20px)' }, to: { opacity: '1', transform: 'translateY(0)' } },
        countAnim: { '0%': { transform: 'scale(1.06)' }, '100%': { transform: 'scale(1)' } },
      },
    },
  },
  plugins: [],
}
export default config
