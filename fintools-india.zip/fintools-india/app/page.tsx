import type { Metadata } from 'next';
import Link from 'next/link';
import { Calculator, TrendingUp, PiggyBank, Receipt, FileText, ArrowRight, Shield, Zap, Star } from 'lucide-react';
import AdBanner from '@/components/AdBanner';

export const metadata: Metadata = {
  title: 'Free EMI, SIP, FD, GST & Income Tax Calculators India 2026',
  description: 'India\'s best free financial calculators — EMI Calculator, SIP Calculator, FD Calculator, GST Calculator & Income Tax Calculator. Accurate, fast, mobile-friendly.',
};

const tools = [
  { href: '/tools/emi-calculator', icon: Calculator, label: 'EMI Calculator', desc: 'Calculate home loan, car loan & personal loan EMI instantly', color: 'var(--emerald)', bg: 'var(--emerald-light)', badge: 'Most Popular' },
  { href: '/tools/sip-calculator', icon: TrendingUp, label: 'SIP Calculator', desc: 'Project your mutual fund SIP returns with compounding', color: 'var(--plum)', bg: 'var(--plum-light)', badge: 'Trending' },
  { href: '/tools/fd-calculator', icon: PiggyBank, label: 'FD Calculator', desc: 'Calculate fixed deposit maturity amount & interest', color: 'var(--amber)', bg: 'var(--amber-light)', badge: null },
  { href: '/tools/gst-calculator', icon: Receipt, label: 'GST Calculator', desc: 'Add or remove GST from any amount in seconds', color: 'var(--coral)', bg: 'var(--coral-light)', badge: null },
  { href: '/tools/income-tax-calculator', icon: FileText, label: 'Tax Calculator', desc: 'Compare old vs new tax regime for FY 2024-25', color: 'var(--emerald)', bg: 'var(--emerald-light)', badge: 'New' },
];

const features = [
  { icon: Zap, title: 'Real-Time Results', desc: 'Calculations update instantly as you adjust sliders — no button press needed.' },
  { icon: Shield, title: 'Bank-Accurate Formulas', desc: 'Uses RBI-standard reducing balance method for EMI and AMFI formulas for SIP.' },
  { icon: Star, title: 'India-Focused', desc: 'Built for Indian investors — rupee formatting, Indian tax slabs, and local context.' },
];

const faqs = [
  { q: 'How is EMI calculated?', a: 'EMI = [P × r × (1+r)^n] / [(1+r)^n – 1], where P is principal, r is monthly rate, n is tenure in months.' },
  { q: 'What is SIP and how does it work?', a: 'SIP (Systematic Investment Plan) lets you invest a fixed amount monthly in mutual funds, harnessing compounding for long-term wealth.' },
  { q: 'Which tax regime is better in 2024?', a: 'For income under ₹7L, the new regime offers zero tax. Above ₹15L, it depends on your deductions — use our Tax Calculator to compare.' },
  { q: 'Is FD or SIP better?', a: 'FDs offer guaranteed ~7% returns. SIPs in equity funds historically return 10–15% but carry market risk. FDs suit short-term, SIPs suit long-term goals.' },
];

export default function HomePage() {
  const schema = {
    '@context': 'https://schema.org',
    '@type': 'FAQPage',
    mainEntity: faqs.map(f => ({ '@type': 'Question', name: f.q, acceptedAnswer: { '@type': 'Answer', text: f.a } })),
  };

  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(schema) }} />

      {/* Ad - Header */}
      <div className="max-w-6xl mx-auto px-4 pt-4">
        <AdBanner slot="1234567890" format="horizontal" style={{ height: 90 }} />
      </div>

      {/* Hero */}
      <section className="py-20 text-center relative overflow-hidden">
        <div className="absolute inset-0 pointer-events-none" style={{ background: 'radial-gradient(ellipse 80% 50% at 50% -10%, var(--emerald-light), transparent)' }} />
        <div className="max-w-4xl mx-auto px-4 relative">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full text-xs font-semibold uppercase tracking-wider mb-6" style={{ background: 'var(--emerald-light)', color: 'var(--emerald)' }}>
            🇮🇳 Made for Indian Investors
          </div>
          <h1 className="font-serif text-5xl md:text-6xl font-bold mb-5 leading-tight" style={{ color: 'var(--text-primary)' }}>
            Smart Finance<br />
            <span style={{ color: 'var(--emerald)' }}>Calculators</span> for India
          </h1>
          <p className="text-lg mb-8 max-w-2xl mx-auto" style={{ color: 'var(--text-secondary)' }}>
            Free, accurate EMI, SIP, FD, GST & Income Tax calculators. Make smarter financial decisions with real-time results and clear breakdowns.
          </p>
          <div className="flex flex-wrap gap-3 justify-center">
            <Link href="/tools/emi-calculator" className="px-6 py-3 rounded-xl text-sm font-semibold text-white transition-transform hover:-translate-y-0.5" style={{ background: 'var(--emerald)' }}>
              EMI Calculator →
            </Link>
            <Link href="/tools/sip-calculator" className="px-6 py-3 rounded-xl text-sm font-semibold transition-transform hover:-translate-y-0.5 border" style={{ borderColor: 'var(--border)', color: 'var(--text-primary)', background: 'var(--bg-card)' }}>
              SIP Calculator
            </Link>
          </div>
        </div>
      </section>

      {/* Tools Grid */}
      <section className="py-16 max-w-6xl mx-auto px-4">
        <div className="text-center mb-10">
          <h2 className="font-serif text-3xl md:text-4xl font-bold mb-3" style={{ color: 'var(--text-primary)' }}>Financial Calculators</h2>
          <p style={{ color: 'var(--text-secondary)' }}>All tools are free, no login required</p>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {tools.map(t => {
            const Icon = t.icon;
            return (
              <Link key={t.href} href={t.href} className="group rounded-2xl border p-6 transition-all hover:-translate-y-1" style={{ background: 'var(--bg-card)', borderColor: 'var(--border)', boxShadow: 'var(--shadow-sm)' }}
                onMouseEnter={e => (e.currentTarget.style.boxShadow = 'var(--shadow-md)')}
                onMouseLeave={e => (e.currentTarget.style.boxShadow = 'var(--shadow-sm)')}>
                <div className="flex items-start justify-between mb-4">
                  <div className="w-12 h-12 rounded-xl flex items-center justify-center" style={{ background: t.bg }}>
                    <Icon size={22} style={{ color: t.color }} />
                  </div>
                  {t.badge && <span className="text-xs font-semibold px-2.5 py-1 rounded-full" style={{ background: t.bg, color: t.color }}>{t.badge}</span>}
                </div>
                <h3 className="font-serif font-semibold text-lg mb-1.5 group-hover:underline" style={{ color: 'var(--text-primary)' }}>{t.label}</h3>
                <p className="text-sm mb-4" style={{ color: 'var(--text-secondary)' }}>{t.desc}</p>
                <span className="flex items-center gap-1 text-xs font-semibold" style={{ color: t.color }}>
                  Calculate now <ArrowRight size={12} className="group-hover:translate-x-1 transition-transform" />
                </span>
              </Link>
            );
          })}
        </div>
      </section>

      {/* Ad - Middle */}
      <div className="max-w-6xl mx-auto px-4 my-8">
        <AdBanner slot="0987654321" format="rectangle" style={{ height: 250 }} />
      </div>

      {/* Features */}
      <section className="py-16 max-w-6xl mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {features.map(f => {
            const Icon = f.icon;
            return (
              <div key={f.title} className="rounded-2xl border p-6" style={{ background: 'var(--bg-card)', borderColor: 'var(--border)' }}>
                <div className="w-10 h-10 rounded-xl flex items-center justify-center mb-4" style={{ background: 'var(--bg-subtle)' }}>
                  <Icon size={20} style={{ color: 'var(--emerald)' }} />
                </div>
                <h3 className="font-semibold mb-2" style={{ color: 'var(--text-primary)' }}>{f.title}</h3>
                <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>{f.desc}</p>
              </div>
            );
          })}
        </div>
      </section>

      {/* FAQs */}
      <section className="py-16 max-w-3xl mx-auto px-4">
        <h2 className="font-serif text-3xl font-bold text-center mb-10" style={{ color: 'var(--text-primary)' }}>Frequently Asked Questions</h2>
        <div className="space-y-4">
          {faqs.map(f => (
            <div key={f.q} className="rounded-2xl border p-6" style={{ background: 'var(--bg-card)', borderColor: 'var(--border)' }}>
              <h3 className="font-semibold mb-2" style={{ color: 'var(--text-primary)' }}>{f.q}</h3>
              <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>{f.a}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Blog CTA */}
      <section className="py-12 max-w-6xl mx-auto px-4 mb-8">
        <div className="rounded-3xl p-10 text-center" style={{ background: 'linear-gradient(135deg, var(--emerald-light), var(--plum-light))' }}>
          <h2 className="font-serif text-3xl font-bold mb-3" style={{ color: 'var(--text-primary)' }}>Finance Tips & Guides</h2>
          <p className="mb-6" style={{ color: 'var(--text-secondary)' }}>In-depth articles on EMI, SIP, tax saving, and smart investing for India</p>
          <Link href="/blog" className="inline-flex items-center gap-2 px-6 py-3 rounded-xl text-sm font-semibold text-white" style={{ background: 'var(--emerald)' }}>
            Read the Blog <ArrowRight size={14} />
          </Link>
        </div>
      </section>
    </>
  );
}
