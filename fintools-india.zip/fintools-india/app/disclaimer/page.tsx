import type { Metadata } from 'next';
import Link from 'next/link';

export const metadata: Metadata = {
  title: 'Disclaimer – FinTools India',
  description: 'Disclaimer for FinTools India. Financial calculators are for informational purposes only.',
};

export default function DisclaimerPage() {
  return (
    <div className="max-w-3xl mx-auto px-4 py-16">
      <nav className="text-xs mb-6 flex items-center gap-2" style={{ color: 'var(--text-muted)' }}>
        <Link href="/" className="hover:underline">Home</Link> / <span style={{ color: 'var(--emerald)' }}>Disclaimer</span>
      </nav>
      <h1 className="font-serif text-4xl font-bold mb-2" style={{ color: 'var(--text-primary)' }}>Disclaimer</h1>
      <p className="text-sm mb-8" style={{ color: 'var(--text-muted)' }}>Last updated: January 1, 2025</p>

      <div className="space-y-6 text-sm leading-relaxed" style={{ color: 'var(--text-secondary)' }}>
        <div className="rounded-2xl border p-5" style={{ background: 'var(--amber-light)', borderColor: 'var(--amber)' }}>
          <p className="font-semibold text-base mb-2" style={{ color: 'var(--text-primary)' }}>⚠️ Important Notice</p>
          <p>FinTools India provides financial calculators and content for <strong>informational and educational purposes only</strong>. This is NOT financial advice.</p>
        </div>

        {[
          { title: 'Not Financial Advice', body: 'The calculators, articles, and content on FinTools India do not constitute financial advice, investment advice, trading advice, or any other type of advice. You should not treat any content on this site as a basis for making financial decisions.' },
          { title: 'Calculator Accuracy', body: 'While our calculators use standard financial formulas, actual EMI amounts, investment returns, FD maturity values, and tax computations may differ from estimates shown. Banks may apply different compounding methods, processing fees, or rounding. Tax computations are simplified and may not account for all provisions of the Income Tax Act.' },
          { title: 'Investment Risk', body: 'Mutual fund and SIP return projections are based on assumed rates of return. Actual returns will vary. Mutual fund investments are subject to market risk. Past performance is not indicative of future results.' },
          { title: 'Tax Disclaimer', body: 'Tax calculators are based on publicly available tax slab information. Tax laws change frequently. Always verify with the Income Tax Department\'s official website (incometax.gov.in) or consult a Chartered Accountant.' },
          { title: 'Professional Advice', body: 'Before making any financial decision — taking a loan, investing in mutual funds, choosing a tax regime — consult a SEBI-registered investment advisor, Chartered Accountant, or other qualified financial professional.' },
          { title: 'Affiliate Disclosure', body: 'FinTools India may display Google AdSense advertisements. We are not paid to recommend any specific financial product, bank, or service. Links to external sites are for reference only.' },
        ].map(s => (
          <section key={s.title}>
            <h2 className="font-serif text-xl font-bold mb-2" style={{ color: 'var(--text-primary)' }}>{s.title}</h2>
            <p>{s.body}</p>
          </section>
        ))}
      </div>
    </div>
  );
}
