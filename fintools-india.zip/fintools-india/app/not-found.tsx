import Link from 'next/link';

export default function NotFound() {
  return (
    <div className="min-h-[70vh] flex items-center justify-center text-center px-4">
      <div>
        <div className="font-serif text-8xl font-bold mb-4" style={{ color: 'var(--emerald)' }}>404</div>
        <h1 className="font-serif text-3xl font-bold mb-3" style={{ color: 'var(--text-primary)' }}>Page Not Found</h1>
        <p className="mb-8 max-w-md" style={{ color: 'var(--text-secondary)' }}>
          This page doesn't exist. Try one of our free financial calculators instead.
        </p>
        <div className="flex flex-wrap gap-3 justify-center">
          <Link href="/" className="px-5 py-2.5 rounded-xl text-sm font-semibold text-white" style={{ background: 'var(--emerald)' }}>← Home</Link>
          <Link href="/tools/emi-calculator" className="px-5 py-2.5 rounded-xl text-sm font-semibold border" style={{ borderColor: 'var(--border)', color: 'var(--text-primary)' }}>EMI Calculator</Link>
          <Link href="/tools/sip-calculator" className="px-5 py-2.5 rounded-xl text-sm font-semibold border" style={{ borderColor: 'var(--border)', color: 'var(--text-primary)' }}>SIP Calculator</Link>
        </div>
      </div>
    </div>
  );
}
