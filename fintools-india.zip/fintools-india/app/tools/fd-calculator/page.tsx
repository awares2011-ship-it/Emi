import type { Metadata } from 'next';
import FDCalculator from '@/components/FDCalculator';
import AdBanner from '@/components/AdBanner';
import Link from 'next/link';

export const metadata: Metadata = {
  title: 'FD Calculator India 2026 – Fixed Deposit Maturity Calculator',
  description: 'Free FD Calculator India. Calculate fixed deposit maturity amount, total interest earned with monthly, quarterly & annual compounding. Compare FD rates across banks.',
  keywords: ['FD calculator India', 'fixed deposit calculator', 'FD maturity calculator', 'FD interest calculator'],
};

export default function FDCalculatorPage() {
  return (
    <div className="max-w-6xl mx-auto px-4 py-10">
      <nav className="text-xs mb-6 flex items-center gap-2" style={{ color: 'var(--text-muted)' }}>
        <Link href="/" className="hover:underline">Home</Link> / <Link href="/tools/fd-calculator" style={{ color: 'var(--amber)' }}>FD Calculator</Link>
      </nav>
      <div className="mb-8">
        <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-semibold mb-3" style={{ background: 'var(--amber-light)', color: 'var(--amber)' }}>🏦 Free FD Calculator</div>
        <h1 className="font-serif text-4xl md:text-5xl font-bold mb-3" style={{ color: 'var(--text-primary)' }}>FD Calculator India</h1>
        <p className="text-lg max-w-2xl" style={{ color: 'var(--text-secondary)' }}>Calculate your Fixed Deposit maturity amount and interest. Compare monthly, quarterly and annual compounding options.</p>
      </div>
      <AdBanner slot="3333333333" format="horizontal" style={{ height: 90, marginBottom: 32 }} />
      <FDCalculator />

      <article className="mt-16 max-w-3xl" style={{ color: 'var(--text-secondary)' }}>
        <h2 className="font-serif text-2xl font-bold mb-4" style={{ color: 'var(--text-primary)' }}>FD vs SIP: Which is Better?</h2>
        <p className="mb-4">Fixed Deposits (FD) offer guaranteed returns (currently 6.5–8% p.a.) with capital protection, making them ideal for risk-averse investors and short-term goals. SIPs in equity mutual funds offer higher historical returns (10–15% p.a.) but carry market risk, making them suitable for long-term goals like retirement or children's education.</p>

        <div className="rounded-xl border overflow-hidden mb-6" style={{ borderColor: 'var(--border)' }}>
          <table className="w-full text-sm">
            <thead style={{ background: 'var(--bg-subtle)' }}>
              <tr>
                <th className="text-left p-3 font-semibold" style={{ color: 'var(--text-secondary)' }}>Feature</th>
                <th className="text-center p-3 font-semibold" style={{ color: 'var(--amber)' }}>FD</th>
                <th className="text-center p-3 font-semibold" style={{ color: 'var(--plum)' }}>SIP</th>
              </tr>
            </thead>
            <tbody>
              {[
                ['Returns', '6–8% (Fixed)', '10–15% (Variable)'],
                ['Risk', 'None', 'Market Risk'],
                ['Tax', 'Taxed at slab rate', 'LTCG @ 10% above ₹1L'],
                ['Liquidity', 'Penalty on early exit', 'Anytime (T+2 days)'],
                ['Best For', 'Short-term, stability', 'Long-term wealth'],
              ].map(([f, fd, sip]) => (
                <tr key={f} className="border-t" style={{ borderColor: 'var(--border)' }}>
                  <td className="p-3 font-medium" style={{ color: 'var(--text-primary)' }}>{f}</td>
                  <td className="p-3 text-center text-xs" style={{ color: 'var(--amber)' }}>{fd}</td>
                  <td className="p-3 text-center text-xs" style={{ color: 'var(--plum)' }}>{sip}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="grid grid-cols-2 gap-3 mt-6">
          <Link href="/tools/sip-calculator" className="rounded-xl border p-4" style={{ background: 'var(--bg-card)', borderColor: 'var(--border)' }}>
            <p className="font-semibold text-sm mb-1" style={{ color: 'var(--text-primary)' }}>SIP Calculator</p>
            <p className="text-xs" style={{ color: 'var(--text-muted)' }}>Compare SIP returns</p>
          </Link>
          <Link href="/tools/income-tax-calculator" className="rounded-xl border p-4" style={{ background: 'var(--bg-card)', borderColor: 'var(--border)' }}>
            <p className="font-semibold text-sm mb-1" style={{ color: 'var(--text-primary)' }}>Tax Calculator</p>
            <p className="text-xs" style={{ color: 'var(--text-muted)' }}>Know FD tax impact</p>
          </Link>
        </div>
      </article>
    </div>
  );
}
