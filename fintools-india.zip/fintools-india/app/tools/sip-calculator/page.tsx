import type { Metadata } from 'next';
import SipCalculator from '@/components/SipCalculator';
import AdBanner from '@/components/AdBanner';
import Link from 'next/link';

export const metadata: Metadata = {
  title: 'SIP Calculator India 2026 – Mutual Fund SIP Returns Calculator',
  description: 'Free SIP Calculator India. Calculate monthly SIP returns, total wealth and compounding benefits. Best SIP calculator for mutual fund planning in India.',
  keywords: ['SIP calculator India', 'SIP returns calculator', 'mutual fund SIP calculator', 'best SIP calculator', 'SIP investment calculator'],
  openGraph: { title: 'SIP Calculator India 2026', description: 'Calculate your SIP returns and projected wealth with compounding.', url: 'https://fintoolsindia.in/tools/sip-calculator' },
};

export default function SipCalculatorPage() {
  return (
    <div className="max-w-6xl mx-auto px-4 py-10">
      <nav className="text-xs mb-6 flex items-center gap-2" style={{ color: 'var(--text-muted)' }}>
        <Link href="/" className="hover:underline">Home</Link> / <Link href="/tools/sip-calculator" style={{ color: 'var(--plum)' }}>SIP Calculator</Link>
      </nav>

      <div className="mb-8">
        <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-semibold mb-3" style={{ background: 'var(--plum-light)', color: 'var(--plum)' }}>
          📈 Free SIP Calculator
        </div>
        <h1 className="font-serif text-4xl md:text-5xl font-bold mb-3" style={{ color: 'var(--text-primary)' }}>SIP Calculator India</h1>
        <p className="text-lg max-w-2xl" style={{ color: 'var(--text-secondary)' }}>
          Calculate your Systematic Investment Plan (SIP) returns with compounding. See how small monthly investments grow into large wealth.
        </p>
      </div>

      <AdBanner slot="2222222222" format="horizontal" style={{ height: 90, marginBottom: 32 }} />
      <SipCalculator />

      <article className="mt-16 max-w-3xl" style={{ color: 'var(--text-secondary)' }}>
        <h2 className="font-serif text-2xl font-bold mb-4" style={{ color: 'var(--text-primary)' }}>What is SIP?</h2>
        <p className="mb-4">A <strong>Systematic Investment Plan (SIP)</strong> allows you to invest a fixed amount in mutual funds at regular intervals (usually monthly). It's one of the most disciplined ways to invest in equity markets without timing the market.</p>

        <h2 className="font-serif text-2xl font-bold mt-8 mb-4" style={{ color: 'var(--text-primary)' }}>SIP Formula</h2>
        <div className="rounded-xl p-4 mb-4 font-mono text-sm" style={{ background: 'var(--bg-subtle)', color: 'var(--plum)' }}>
          M = P × [((1+i)^n – 1) / i] × (1+i)
        </div>
        <p className="mb-4 text-sm">Where <strong>M</strong> = Maturity Amount, <strong>P</strong> = Monthly SIP amount, <strong>i</strong> = Monthly interest rate, <strong>n</strong> = Number of months</p>

        <h2 className="font-serif text-2xl font-bold mt-8 mb-4" style={{ color: 'var(--text-primary)' }}>Benefits of SIP</h2>
        <ul className="space-y-2 list-disc list-inside mb-4 text-sm">
          <li><strong>Rupee Cost Averaging</strong> — Buy more units when markets fall, fewer when markets rise</li>
          <li><strong>Power of Compounding</strong> — Returns generate further returns over time</li>
          <li><strong>Disciplined Investing</strong> — Automatic deductions build saving habits</li>
          <li><strong>Start Small</strong> — Begin with as little as ₹500/month</li>
          <li><strong>Flexible</strong> — Pause, increase, or stop anytime</li>
        </ul>

        <h2 className="font-serif text-2xl font-bold mt-8 mb-4" style={{ color: 'var(--text-primary)' }}>Top Performing SIP Funds (2024)</h2>
        <div className="rounded-xl border overflow-hidden mb-4" style={{ borderColor: 'var(--border)' }}>
          <table className="w-full text-sm">
            <thead style={{ background: 'var(--bg-subtle)' }}>
              <tr><th className="text-left p-3 font-semibold" style={{ color: 'var(--text-secondary)' }}>Fund</th><th className="text-right p-3 font-semibold" style={{ color: 'var(--text-secondary)' }}>5Y Returns</th></tr>
            </thead>
            <tbody>
              {[['Mirae Asset Large Cap Fund', '~16%'], ['Axis Bluechip Fund', '~14%'], ['Parag Parikh Flexicap Fund', '~20%'], ['SBI Small Cap Fund', '~24%']].map(([f, r]) => (
                <tr key={f} className="border-t" style={{ borderColor: 'var(--border)' }}>
                  <td className="p-3" style={{ color: 'var(--text-primary)' }}>{f}</td>
                  <td className="p-3 text-right font-semibold" style={{ color: 'var(--plum)' }}>{r}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <p className="text-xs mb-8" style={{ color: 'var(--text-muted)' }}>*Past returns do not guarantee future performance. Mutual fund investments are subject to market risk.</p>

        <div className="grid grid-cols-2 gap-3">
          <Link href="/tools/emi-calculator" className="rounded-xl border p-4" style={{ background: 'var(--bg-card)', borderColor: 'var(--border)' }}>
            <p className="font-semibold text-sm mb-1" style={{ color: 'var(--text-primary)' }}>EMI Calculator</p>
            <p className="text-xs" style={{ color: 'var(--text-muted)' }}>Calculate loan EMI</p>
          </Link>
          <Link href="/tools/fd-calculator" className="rounded-xl border p-4" style={{ background: 'var(--bg-card)', borderColor: 'var(--border)' }}>
            <p className="font-semibold text-sm mb-1" style={{ color: 'var(--text-primary)' }}>FD Calculator</p>
            <p className="text-xs" style={{ color: 'var(--text-muted)' }}>Compare FD vs SIP</p>
          </Link>
        </div>
      </article>
    </div>
  );
}
