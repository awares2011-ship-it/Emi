import type { Metadata } from 'next';
import EmiCalculator from '@/components/EmiCalculator';
import AdBanner from '@/components/AdBanner';
import Link from 'next/link';

export const metadata: Metadata = {
  title: 'EMI Calculator India 2026 – Home Loan, Car Loan, Personal Loan',
  description: 'Free EMI Calculator India. Calculate monthly EMI for home loan, car loan & personal loan. Uses bank-accurate reducing balance formula. Instant results with Chart.',
  keywords: ['EMI calculator India', 'home loan EMI calculator', 'car loan EMI', 'personal loan EMI', 'loan EMI calculator online'],
  openGraph: {
    title: 'EMI Calculator India 2026',
    description: 'Calculate your loan EMI instantly. Accurate, fast, free.',
    url: 'https://fintoolsindia.in/tools/emi-calculator',
  },
};

const schema = {
  '@context': 'https://schema.org',
  '@type': 'FAQPage',
  mainEntity: [
    { '@type': 'Question', name: 'What is the EMI formula?', acceptedAnswer: { '@type': 'Answer', text: 'EMI = [P × r × (1+r)^n] / [(1+r)^n – 1]. P = Principal, r = Monthly rate (Annual rate ÷ 12 ÷ 100), n = Tenure in months.' } },
    { '@type': 'Question', name: 'What is the current home loan rate in India?', acceptedAnswer: { '@type': 'Answer', text: 'Home loan rates in India range from 8.40% to 9.50% p.a. as of 2024, depending on your bank and credit score.' } },
    { '@type': 'Question', name: 'Can I prepay my home loan?', acceptedAnswer: { '@type': 'Answer', text: 'Yes. RBI mandates that banks cannot charge prepayment penalties on floating rate home loans. Prepaying reduces your interest burden significantly.' } },
  ],
};

export default function EmiCalculatorPage() {
  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(schema) }} />
      <div className="max-w-6xl mx-auto px-4 py-10">
        {/* Breadcrumb */}
        <nav className="text-xs mb-6 flex items-center gap-2" style={{ color: 'var(--text-muted)' }}>
          <Link href="/" className="hover:underline">Home</Link> / <Link href="/tools/emi-calculator" style={{ color: 'var(--emerald)' }}>EMI Calculator</Link>
        </nav>

        {/* Header */}
        <div className="mb-8">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-semibold mb-3" style={{ background: 'var(--emerald-light)', color: 'var(--emerald)' }}>
            🏠 Free EMI Calculator
          </div>
          <h1 className="font-serif text-4xl md:text-5xl font-bold mb-3" style={{ color: 'var(--text-primary)' }}>EMI Calculator India</h1>
          <p className="text-lg max-w-2xl" style={{ color: 'var(--text-secondary)' }}>
            Calculate your monthly loan EMI instantly. Works for home loans, car loans, personal loans, and education loans.
          </p>
        </div>

        <AdBanner slot="1111111111" format="horizontal" style={{ height: 90, marginBottom: 32 }} />

        <EmiCalculator />

        {/* Article Content */}
        <article className="mt-16 max-w-3xl" style={{ color: 'var(--text-secondary)' }}>
          <h2 className="font-serif text-2xl font-bold mb-4" style={{ color: 'var(--text-primary)' }}>How EMI is Calculated</h2>
          <p className="mb-4">The <strong>EMI formula</strong> uses the reducing balance method:</p>
          <div className="rounded-xl p-4 mb-4 font-mono text-sm" style={{ background: 'var(--bg-subtle)', color: 'var(--emerald)' }}>
            EMI = [P × r × (1+r)^n] / [(1+r)^n – 1]
          </div>
          <p className="mb-4">Where <strong>P</strong> = Principal amount, <strong>r</strong> = Monthly interest rate (Annual Rate ÷ 12 ÷ 100), <strong>n</strong> = Total tenure in months.</p>

          <h2 className="font-serif text-2xl font-bold mt-8 mb-4" style={{ color: 'var(--text-primary)' }}>Tips to Reduce Your EMI</h2>
          <ul className="space-y-2 list-disc list-inside mb-4 text-sm">
            <li>Make a larger down payment to reduce the principal</li>
            <li>Choose a longer tenure to spread EMI (but you pay more interest overall)</li>
            <li>Maintain a CIBIL score above 750 to get lower interest rates</li>
            <li>Compare rates across banks — even 0.5% difference saves lakhs on a ₹50L loan</li>
            <li>Prepay whenever possible to reduce interest burden</li>
          </ul>

          <h2 className="font-serif text-2xl font-bold mt-8 mb-4" style={{ color: 'var(--text-primary)' }}>Current Home Loan Rates (2024)</h2>
          <div className="rounded-xl border overflow-hidden mb-6" style={{ borderColor: 'var(--border)' }}>
            <table className="w-full text-sm">
              <thead style={{ background: 'var(--bg-subtle)' }}>
                <tr><th className="text-left p-3 font-semibold" style={{ color: 'var(--text-secondary)' }}>Bank</th><th className="text-right p-3 font-semibold" style={{ color: 'var(--text-secondary)' }}>Rate (p.a.)</th></tr>
              </thead>
              <tbody>
                {[['SBI', '8.50%'], ['HDFC Bank', '8.70%'], ['ICICI Bank', '8.75%'], ['Axis Bank', '8.75%'], ['Kotak Mahindra', '8.70%']].map(([b, r]) => (
                  <tr key={b} className="border-t" style={{ borderColor: 'var(--border)' }}>
                    <td className="p-3" style={{ color: 'var(--text-primary)' }}>{b}</td>
                    <td className="p-3 text-right font-semibold" style={{ color: 'var(--emerald)' }}>{r}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <p className="text-xs" style={{ color: 'var(--text-muted)' }}>*Rates are indicative and subject to change. Check directly with the bank.</p>

          <h2 className="font-serif text-2xl font-bold mt-8 mb-4" style={{ color: 'var(--text-primary)' }}>Related Calculators</h2>
          <div className="grid grid-cols-2 gap-3">
            {[
              { href: '/tools/sip-calculator', label: 'SIP Calculator', desc: 'Grow wealth via SIP' },
              { href: '/tools/fd-calculator', label: 'FD Calculator', desc: 'Calculate FD returns' },
            ].map(c => (
              <Link key={c.href} href={c.href} className="rounded-xl border p-4 hover:underline" style={{ background: 'var(--bg-card)', borderColor: 'var(--border)' }}>
                <p className="font-semibold text-sm mb-1" style={{ color: 'var(--text-primary)' }}>{c.label}</p>
                <p className="text-xs" style={{ color: 'var(--text-muted)' }}>{c.desc}</p>
              </Link>
            ))}
          </div>
        </article>
      </div>
    </>
  );
}
