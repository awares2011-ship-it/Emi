import type { Metadata } from 'next';
import GSTCalculator from '@/components/GSTCalculator';
import AdBanner from '@/components/AdBanner';
import Link from 'next/link';

export const metadata: Metadata = {
  title: 'GST Calculator Online India 2026 – Add or Remove GST Instantly',
  description: 'Free GST Calculator India. Add or remove GST from any amount. Supports 5%, 12%, 18%, 28% slabs. Shows CGST, SGST breakdown. Instant calculation.',
  keywords: ['GST calculator online', 'GST calculator India', 'GST calculator', 'add GST calculator', 'remove GST calculator', 'CGST SGST calculator'],
};

export default function GSTCalculatorPage() {
  return (
    <div className="max-w-6xl mx-auto px-4 py-10">
      <nav className="text-xs mb-6 flex items-center gap-2" style={{ color: 'var(--text-muted)' }}>
        <Link href="/" className="hover:underline">Home</Link> / <Link href="/tools/gst-calculator" style={{ color: 'var(--coral)' }}>GST Calculator</Link>
      </nav>
      <div className="mb-8">
        <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-semibold mb-3" style={{ background: 'var(--coral-light)', color: 'var(--coral)' }}>🧾 Free GST Calculator</div>
        <h1 className="font-serif text-4xl md:text-5xl font-bold mb-3" style={{ color: 'var(--text-primary)' }}>GST Calculator Online India</h1>
        <p className="text-lg max-w-2xl" style={{ color: 'var(--text-secondary)' }}>Add or remove GST from any amount instantly. See CGST and SGST breakdown for all GST slabs.</p>
      </div>
      <AdBanner slot="4444444444" format="horizontal" style={{ height: 90, marginBottom: 32 }} />
      <GSTCalculator />

      <article className="mt-16 max-w-3xl" style={{ color: 'var(--text-secondary)' }}>
        <h2 className="font-serif text-2xl font-bold mb-4" style={{ color: 'var(--text-primary)' }}>Understanding GST in India</h2>
        <p className="mb-4">Goods and Services Tax (GST) is India's unified indirect tax that replaced multiple taxes like VAT, Service Tax, and Excise Duty. It was implemented on 1 July 2017.</p>

        <h2 className="font-serif text-2xl font-bold mt-8 mb-4" style={{ color: 'var(--text-primary)' }}>GST Slabs</h2>
        <div className="grid grid-cols-2 gap-3 mb-6">
          {[
            { rate: '0%', items: 'Essential goods — fresh vegetables, milk, eggs, education', color: 'var(--emerald)' },
            { rate: '5%', items: 'Daily use items — packaged food, transport services', color: 'var(--amber)' },
            { rate: '12%', items: 'Processed food, business class airfare, mobile phones', color: 'var(--coral)' },
            { rate: '18%', items: 'Most services, electronics, restaurants, software', color: 'var(--plum)' },
          ].map(g => (
            <div key={g.rate} className="rounded-xl border p-4" style={{ background: 'var(--bg-card)', borderColor: 'var(--border)' }}>
              <p className="text-2xl font-bold mb-1" style={{ color: g.color }}>{g.rate}</p>
              <p className="text-xs" style={{ color: 'var(--text-muted)' }}>{g.items}</p>
            </div>
          ))}
        </div>
        <div className="rounded-xl border p-4 mb-6" style={{ background: 'var(--bg-card)', borderColor: 'var(--border)' }}>
          <p className="text-2xl font-bold mb-1" style={{ color: 'var(--coral)' }}>28%</p>
          <p className="text-xs" style={{ color: 'var(--text-muted)' }}>Luxury goods — automobiles, tobacco, aerated drinks, casinos</p>
        </div>

        <h2 className="font-serif text-2xl font-bold mt-8 mb-4" style={{ color: 'var(--text-primary)' }}>CGST vs SGST vs IGST</h2>
        <p className="text-sm mb-4">GST is split between Central and State governments:</p>
        <ul className="space-y-2 text-sm list-disc list-inside mb-6">
          <li><strong>CGST</strong> — Central GST (50% of total GST) on intra-state transactions</li>
          <li><strong>SGST</strong> — State GST (50% of total GST) on intra-state transactions</li>
          <li><strong>IGST</strong> — Integrated GST (100%) on inter-state transactions</li>
        </ul>
      </article>
    </div>
  );
}
