import type { Metadata } from 'next';
import TaxCalculator from '@/components/TaxCalculator';
import AdBanner from '@/components/AdBanner';
import Link from 'next/link';

export const metadata: Metadata = {
  title: 'Income Tax Calculator India 2024-25 – New vs Old Regime',
  description: 'Free Income Tax Calculator India FY 2024-25. Compare new vs old tax regime. Calculate exact tax with 80C deductions, HRA, NPS. Instant tax computation.',
  keywords: ['income tax calculator India', 'income tax calculator 2024-25', 'new tax regime calculator', 'old tax regime calculator', 'tax calculator India'],
};

export default function TaxCalculatorPage() {
  return (
    <div className="max-w-6xl mx-auto px-4 py-10">
      <nav className="text-xs mb-6 flex items-center gap-2" style={{ color: 'var(--text-muted)' }}>
        <Link href="/" className="hover:underline">Home</Link> / <Link href="/tools/income-tax-calculator" style={{ color: 'var(--coral)' }}>Tax Calculator</Link>
      </nav>
      <div className="mb-8">
        <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-semibold mb-3" style={{ background: 'var(--coral-light)', color: 'var(--coral)' }}>📊 FY 2024-25</div>
        <h1 className="font-serif text-4xl md:text-5xl font-bold mb-3" style={{ color: 'var(--text-primary)' }}>Income Tax Calculator India</h1>
        <p className="text-lg max-w-2xl" style={{ color: 'var(--text-secondary)' }}>Compare New vs Old tax regime for FY 2024-25 (AY 2025-26). Calculate exact income tax with deductions.</p>
      </div>
      <AdBanner slot="5555555555" format="horizontal" style={{ height: 90, marginBottom: 32 }} />
      <TaxCalculator />

      <article className="mt-16 max-w-3xl" style={{ color: 'var(--text-secondary)' }}>
        <h2 className="font-serif text-2xl font-bold mb-4" style={{ color: 'var(--text-primary)' }}>New Tax Regime vs Old Tax Regime (FY 2024-25)</h2>

        <div className="rounded-xl border overflow-hidden mb-6" style={{ borderColor: 'var(--border)' }}>
          <table className="w-full text-sm">
            <thead style={{ background: 'var(--bg-subtle)' }}>
              <tr>
                <th className="text-left p-3 font-semibold" style={{ color: 'var(--text-secondary)' }}>Income Slab</th>
                <th className="text-center p-3 font-semibold" style={{ color: 'var(--plum)' }}>New Regime</th>
                <th className="text-center p-3 font-semibold" style={{ color: 'var(--amber)' }}>Old Regime</th>
              </tr>
            </thead>
            <tbody>
              {[
                ['Up to ₹3 lakh', '0%', '0%'],
                ['₹3L – ₹6L', '5%', '5%'],
                ['₹6L – ₹9L', '10%', '20%'],
                ['₹9L – ₹12L', '15%', '20%'],
                ['₹12L – ₹15L', '20%', '30%'],
                ['Above ₹15L', '30%', '30%'],
              ].map(([slab, nr, or_]) => (
                <tr key={slab} className="border-t" style={{ borderColor: 'var(--border)' }}>
                  <td className="p-3" style={{ color: 'var(--text-primary)' }}>{slab}</td>
                  <td className="p-3 text-center font-semibold" style={{ color: 'var(--plum)' }}>{nr}</td>
                  <td className="p-3 text-center font-semibold" style={{ color: 'var(--amber)' }}>{or_}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <h2 className="font-serif text-2xl font-bold mt-8 mb-4" style={{ color: 'var(--text-primary)' }}>Which Regime is Better?</h2>
        <div className="space-y-3 mb-6">
          <div className="rounded-xl border p-4" style={{ background: 'var(--bg-card)', borderColor: 'var(--border)' }}>
            <p className="font-semibold text-sm mb-1" style={{ color: 'var(--plum)' }}>Choose New Regime if:</p>
            <ul className="text-xs space-y-1 list-disc list-inside" style={{ color: 'var(--text-muted)' }}>
              <li>Your annual income is under ₹7 lakh (zero tax with rebate 87A)</li>
              <li>You have few deductions (no HRA, 80C is low)</li>
              <li>You prefer simplicity over tax planning</li>
            </ul>
          </div>
          <div className="rounded-xl border p-4" style={{ background: 'var(--bg-card)', borderColor: 'var(--border)' }}>
            <p className="font-semibold text-sm mb-1" style={{ color: 'var(--amber)' }}>Choose Old Regime if:</p>
            <ul className="text-xs space-y-1 list-disc list-inside" style={{ color: 'var(--text-muted)' }}>
              <li>You have high deductions (₹1.5L+ in 80C, HRA, NPS)</li>
              <li>Your income exceeds ₹15 lakh with maximum deductions</li>
              <li>You have a home loan with significant interest paid</li>
            </ul>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3 mt-6">
          <Link href="/tools/emi-calculator" className="rounded-xl border p-4" style={{ background: 'var(--bg-card)', borderColor: 'var(--border)' }}>
            <p className="font-semibold text-sm mb-1" style={{ color: 'var(--text-primary)' }}>EMI Calculator</p>
            <p className="text-xs" style={{ color: 'var(--text-muted)' }}>Home loan tax benefit (Sec 24)</p>
          </Link>
          <Link href="/tools/sip-calculator" className="rounded-xl border p-4" style={{ background: 'var(--bg-card)', borderColor: 'var(--border)' }}>
            <p className="font-semibold text-sm mb-1" style={{ color: 'var(--text-primary)' }}>SIP Calculator</p>
            <p className="text-xs" style={{ color: 'var(--text-muted)' }}>ELSS saves 80C tax</p>
          </Link>
        </div>
      </article>
    </div>
  );
}
