import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { getPostBySlug, getAllPosts } from '@/lib/blog';
import AdBanner from '@/components/AdBanner';
import BlogCard from '@/components/BlogCard';
import Link from 'next/link';
import { Clock, Calendar, ArrowLeft } from 'lucide-react';

interface Props { params: { slug: string } }

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const post = await getPostBySlug(params.slug);
  if (!post) return {};
  return {
    title: post.metaTitle || post.title,
    description: post.metaDescription || post.excerpt,
    openGraph: {
      title: post.metaTitle || post.title,
      description: post.metaDescription || post.excerpt,
      url: `https://fintoolsindia.in/blog/${post.slug}`,
      type: 'article',
    },
  };
}

export default async function BlogPostPage({ params }: Props) {
  const [post, allPosts] = await Promise.all([getPostBySlug(params.slug), getAllPosts()]);
  if (!post) notFound();

  const related = allPosts.filter(p => p.slug !== post.slug && p.category === post.category).slice(0, 3);
  const date = post.createdAt instanceof Date ? post.createdAt : (post.createdAt as { toDate: () => Date }).toDate?.() ?? new Date();

  const articleSchema = {
    '@context': 'https://schema.org',
    '@type': 'Article',
    headline: post.title,
    description: post.metaDescription,
    datePublished: date.toISOString(),
    author: { '@type': 'Organization', name: 'FinTools India' },
    publisher: { '@type': 'Organization', name: 'FinTools India', url: 'https://fintoolsindia.in' },
  };

  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(articleSchema) }} />
      <div className="max-w-6xl mx-auto px-4 py-10">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
          {/* Main Content */}
          <article className="lg:col-span-2">
            <nav className="text-xs mb-6 flex items-center gap-2" style={{ color: 'var(--text-muted)' }}>
              <Link href="/" className="hover:underline">Home</Link> /
              <Link href="/blog" className="hover:underline">Blog</Link> /
              <span style={{ color: 'var(--emerald)' }}>{post.title.slice(0, 40)}...</span>
            </nav>

            <Link href="/blog" className="inline-flex items-center gap-2 text-sm mb-6 hover:underline" style={{ color: 'var(--text-muted)' }}>
              <ArrowLeft size={14} /> Back to Blog
            </Link>

            <div className="mb-6">
              <span className="text-xs font-semibold px-3 py-1.5 rounded-full uppercase tracking-wider" style={{ background: 'var(--emerald-light)', color: 'var(--emerald)' }}>
                {post.category}
              </span>
            </div>

            <h1 className="font-serif text-3xl md:text-4xl font-bold mb-4 leading-tight" style={{ color: 'var(--text-primary)' }}>
              {post.title}
            </h1>

            <div className="flex items-center gap-4 mb-8 pb-6 border-b" style={{ borderColor: 'var(--border)' }}>
              <div className="flex items-center gap-1.5 text-sm" style={{ color: 'var(--text-muted)' }}>
                <Calendar size={13} />
                {date.toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' })}
              </div>
              <div className="flex items-center gap-1.5 text-sm" style={{ color: 'var(--text-muted)' }}>
                <Clock size={13} />
                {post.readTime ?? 5} min read
              </div>
            </div>

            <AdBanner slot="7777777777" format="horizontal" style={{ height: 90, marginBottom: 32 }} />

            {/* Blog Content */}
            <div className="prose-content max-w-none" style={{ color: 'var(--text-secondary)' }}
              dangerouslySetInnerHTML={{ __html: post.content }} />

            <AdBanner slot="8888888888" format="rectangle" style={{ height: 250, marginTop: 40 }} />
          </article>

          {/* Sidebar */}
          <aside className="space-y-6">
            {/* Tools CTA */}
            <div className="rounded-2xl border p-5 sticky top-24" style={{ background: 'var(--bg-card)', borderColor: 'var(--border)' }}>
              <h3 className="font-serif font-bold text-lg mb-4" style={{ color: 'var(--text-primary)' }}>Free Calculators</h3>
              <div className="space-y-2">
                {[
                  { href: '/tools/emi-calculator', label: '🏠 EMI Calculator', color: 'var(--emerald)' },
                  { href: '/tools/sip-calculator', label: '📈 SIP Calculator', color: 'var(--plum)' },
                  { href: '/tools/fd-calculator', label: '🏦 FD Calculator', color: 'var(--amber)' },
                  { href: '/tools/gst-calculator', label: '🧾 GST Calculator', color: 'var(--coral)' },
                  { href: '/tools/income-tax-calculator', label: '📊 Tax Calculator', color: 'var(--emerald)' },
                ].map(c => (
                  <Link key={c.href} href={c.href} className="block px-4 py-2.5 rounded-xl border text-sm font-medium transition-colors" style={{ borderColor: 'var(--border)', color: c.color, background: 'var(--bg-subtle)' }}>
                    {c.label}
                  </Link>
                ))}
              </div>

              <AdBanner slot="9999999999" format="rectangle" style={{ height: 250, marginTop: 20 }} />
            </div>
          </aside>
        </div>

        {/* Related Posts */}
        {related.length > 0 && (
          <section className="mt-16">
            <h2 className="font-serif text-2xl font-bold mb-6" style={{ color: 'var(--text-primary)' }}>Related Articles</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
              {related.map(p => <BlogCard key={p.id} post={p} />)}
            </div>
          </section>
        )}
      </div>
    </>
  );
}
