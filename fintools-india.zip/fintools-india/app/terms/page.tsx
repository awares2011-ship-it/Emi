import type { Metadata } from 'next';
import Link from 'next/link';

export const metadata: Metadata = {
  title: 'Terms & Conditions – FinTools India',
  description: 'Terms and Conditions for using FinTools India financial calculators.',
};

export default function TermsPage() {
  return (
    <div className="max-w-3xl mx-auto px-4 py-16">
      <nav className="text-xs mb-6 flex items-center gap-2" style={{ color: 'var(--text-muted)' }}>
        <Link href="/" className="hover:underline">Home</Link> / <span style={{ color: 'var(--emerald)' }}>Terms & Conditions</span>
      </nav>
      <h1 className="font-serif text-4xl font-bold mb-2" style={{ color: 'var(--text-primary)' }}>Terms & Conditions</h1>
      <p className="text-sm mb-8" style={{ color: 'var(--text-muted)' }}>Last updated: January 1, 2025</p>

      <div className="space-y-8 text-sm leading-relaxed" style={{ color: 'var(--text-secondary)' }}>
        {[
          { title: '1. Acceptance of Terms', body: 'By accessing and using FinTools India ("the Site"), you accept and agree to these Terms and Conditions. If you do not agree, please do not use our services.' },
          { title: '2. Use of Calculators', body: 'Our financial calculators are provided for informational and educational purposes only. The results generated are estimates based on the inputs you provide and standard mathematical formulas. They should not be treated as financial advice.' },
          { title: '3. No Financial Advice', body: 'FinTools India is not a SEBI-registered investment advisor, IRDAI-registered insurance advisor, or RBI-licensed financial institution. Nothing on this site constitutes financial, legal, or tax advice. Always consult a qualified professional before making financial decisions.' },
          { title: '4. Accuracy of Information', body: 'While we strive for accuracy, we make no warranty that the calculators, interest rates, tax slabs, or other information on the site are error-free, complete, or current. Rates and tax rules change — always verify with official sources (RBI, SEBI, Income Tax Department).' },
          { title: '5. Intellectual Property', body: 'All content, design, and code on FinTools India is the property of FinTools India and is protected by applicable intellectual property laws. You may not reproduce or distribute content without written permission.' },
          { title: '6. Limitation of Liability', body: 'FinTools India shall not be liable for any direct, indirect, incidental, or consequential damages arising from your use of the site or reliance on its calculators or content.' },
          { title: '7. Governing Law', body: 'These Terms are governed by the laws of India. Any disputes shall be subject to the exclusive jurisdiction of courts in India.' },
          { title: '8. Contact', body: 'For questions about these Terms, email us at hello@fintoolsindia.in' },
        ].map(s => (
          <section key={s.title}>
            <h2 className="font-serif text-xl font-bold mb-2" style={{ color: 'var(--text-primary)' }}>{s.title}</h2>
            <p>{s.body}</p>
          </section>
        ))}
      </div>
    </div>
  );
}
