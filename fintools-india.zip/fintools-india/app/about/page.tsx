import type { Metadata } from 'next';
import Link from 'next/link';

export const metadata: Metadata = {
  title: 'About Us – FinTools India',
  description: 'FinTools India provides free, accurate financial calculators for Indian investors. Learn about our mission to democratize financial planning.',
};

export default function AboutPage() {
  return (
    <div className="max-w-3xl mx-auto px-4 py-16">
      <nav className="text-xs mb-6 flex items-center gap-2" style={{ color: 'var(--text-muted)' }}>
        <Link href="/" className="hover:underline">Home</Link> / <span style={{ color: 'var(--emerald)' }}>About</span>
      </nav>

      <h1 className="font-serif text-4xl font-bold mb-6" style={{ color: 'var(--text-primary)' }}>About FinTools India</h1>

      <div className="space-y-6 text-base leading-relaxed" style={{ color: 'var(--text-secondary)' }}>
        <p>
          <strong style={{ color: 'var(--text-primary)' }}>FinTools India</strong> is a free financial tools platform built specifically for Indian investors, borrowers, and taxpayers. Our mission is to make financial planning simple, accurate, and accessible to every Indian.
        </p>

        <h2 className="font-serif text-2xl font-bold mt-8" style={{ color: 'var(--text-primary)' }}>Our Mission</h2>
        <p>
          We believe every Indian deserves access to accurate financial tools — without paywalls, without login requirements, and without complexity. Our calculators use bank-accurate formulas and India-specific data to give you reliable results instantly.
        </p>

        <h2 className="font-serif text-2xl font-bold mt-8" style={{ color: 'var(--text-primary)' }}>What We Offer</h2>
        <ul className="space-y-2 list-disc list-inside">
          <li><strong>EMI Calculator</strong> — For home loans, car loans, personal loans using RBI-standard reducing balance method</li>
          <li><strong>SIP Calculator</strong> — Mutual fund SIP projections with AMFI-standard compounding formula</li>
          <li><strong>FD Calculator</strong> — Fixed deposit maturity with monthly, quarterly, and annual compounding</li>
          <li><strong>GST Calculator</strong> — Add or remove GST with CGST/SGST breakdown</li>
          <li><strong>Income Tax Calculator</strong> — New vs Old regime comparison for FY 2024-25</li>
        </ul>

        <h2 className="font-serif text-2xl font-bold mt-8" style={{ color: 'var(--text-primary)' }}>Accuracy & Trust</h2>
        <p>
          All our calculators are regularly benchmarked against leading Indian banks (SBI, HDFC, ICICI) and AMFI-registered mutual fund platforms to ensure accuracy. We follow RBI guidelines for EMI calculations and Income Tax Department guidelines for tax computations.
        </p>

        <h2 className="font-serif text-2xl font-bold mt-8" style={{ color: 'var(--text-primary)' }}>Disclaimer</h2>
        <p>
          FinTools India provides financial calculators for informational purposes only. We are not SEBI-registered investment advisors. Our tools should not be treated as financial advice. Please consult a qualified financial advisor before making investment decisions.
        </p>

        <div className="mt-10 p-6 rounded-2xl border" style={{ background: 'var(--bg-subtle)', borderColor: 'var(--border)' }}>
          <p className="font-semibold mb-2" style={{ color: 'var(--text-primary)' }}>Get in Touch</p>
          <p className="text-sm mb-3">Have feedback, found an error, or want to suggest a new calculator?</p>
          <Link href="/contact" className="inline-block px-5 py-2.5 rounded-xl text-sm font-semibold text-white" style={{ background: 'var(--emerald)' }}>
            Contact Us
          </Link>
        </div>
      </div>
    </div>
  );
}
