// app/layout.tsx
import type { Metadata } from 'next';
import '../styles/globals.css';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import { ThemeProvider } from '@/components/ThemeProvider';
import Script from 'next/script';

export const metadata: Metadata = {
  metadataBase: new URL('https://fintoolsindia.in'),
  title: {
    default: 'FinTools India – Free EMI, SIP, FD, GST & Tax Calculators',
    template: '%s | FinTools India',
  },
  description: 'Free online financial calculators for India — EMI Calculator, SIP Calculator, FD Calculator, GST Calculator, Income Tax Calculator. Smart tools for Indian investors.',
  keywords: ['EMI calculator India', 'SIP calculator India', 'GST calculator online', 'income tax calculator India', 'FD calculator', 'home loan EMI', 'mutual fund SIP'],
  authors: [{ name: 'FinTools India' }],
  robots: { index: true, follow: true },
  openGraph: {
    type: 'website',
    locale: 'en_IN',
    url: 'https://fintoolsindia.in',
    siteName: 'FinTools India',
    title: 'FinTools India – Smart Finance Calculators for India',
    description: 'Free EMI, SIP, FD, GST & Income Tax calculators. Built for Indian investors.',
    images: [{ url: '/og-image.png', width: 1200, height: 630, alt: 'FinTools India' }],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'FinTools India – Free Finance Calculators',
    description: 'EMI, SIP, FD, GST & Tax calculators for India',
  },
};

const GA_ID = process.env.NEXT_PUBLIC_GA_ID;

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@400;600;700&family=Outfit:wght@300;400;500;600;700&display=swap" rel="stylesheet" />
        {GA_ID && (
          <>
            <Script src={`https://www.googletagmanager.com/gtag/js?id=${GA_ID}`} strategy="afterInteractive" />
            <Script id="ga-init" strategy="afterInteractive">{`
              window.dataLayer = window.dataLayer || [];
              function gtag(){dataLayer.push(arguments);}
              gtag('js', new Date());
              gtag('config', '${GA_ID}');
            `}</Script>
          </>
        )}
        <Script
          id="website-schema"
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              '@context': 'https://schema.org',
              '@type': 'WebSite',
              name: 'FinTools India',
              url: 'https://fintoolsindia.in',
              description: 'Free online financial calculators for India',
              potentialAction: {
                '@type': 'SearchAction',
                target: 'https://fintoolsindia.in/blog?q={search_term_string}',
                'query-input': 'required name=search_term_string',
              },
            }),
          }}
        />
      </head>
      <body>
        <ThemeProvider>
          <Navbar />
          <main>{children}</main>
          <Footer />
        </ThemeProvider>
      </body>
    </html>
  );
}
