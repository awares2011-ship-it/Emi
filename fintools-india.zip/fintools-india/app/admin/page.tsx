'use client';
import { useState, useEffect } from 'react';
import { signInWithEmailAndPassword, signOut, onAuthStateChanged, User } from 'firebase/auth';
import { auth } from '@/lib/firebase';
import { getAllPosts, createPost, updatePost, deletePost, generateSlug, calculateReadTime } from '@/lib/blog';
import type { BlogPost } from '@/lib/blog';
import { Trash2, Edit2, Plus, LogOut, Eye, EyeOff, Save, X } from 'lucide-react';

type View = 'list' | 'create' | 'edit';

const EMPTY_POST: Omit<BlogPost, 'id' | 'createdAt'> = {
  title: '', slug: '', content: '', excerpt: '',
  metaTitle: '', metaDescription: '', category: 'general',
  tags: [], published: false, readTime: 5,
};

export default function AdminPage() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loginError, setLoginError] = useState('');
  const [showPw, setShowPw] = useState(false);
  const [posts, setPosts] = useState<BlogPost[]>([]);
  const [view, setView] = useState<View>('list');
  const [editPost, setEditPost] = useState<BlogPost | null>(null);
  const [form, setForm] = useState<Omit<BlogPost, 'id' | 'createdAt'>>(EMPTY_POST);
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState('');

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, u => { setUser(u); setLoading(false); });
    return unsub;
  }, []);

  useEffect(() => {
    if (user) loadPosts();
  }, [user]);

  const loadPosts = async () => {
    const data = await getAllPosts(false);
    setPosts(data);
  };

  const login = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError('');
    try {
      await signInWithEmailAndPassword(auth, email, password);
    } catch {
      setLoginError('Invalid email or password');
    }
  };

  const logout = () => signOut(auth);

  const openCreate = () => { setForm(EMPTY_POST); setEditPost(null); setView('create'); };
  const openEdit = (post: BlogPost) => {
    setEditPost(post);
    setForm({ title: post.title, slug: post.slug, content: post.content, excerpt: post.excerpt, metaTitle: post.metaTitle, metaDescription: post.metaDescription, category: post.category, tags: post.tags, published: post.published, readTime: post.readTime ?? 5 });
    setView('edit');
  };

  const handleTitleChange = (title: string) => {
    setForm(p => ({ ...p, title, slug: p.slug || generateSlug(title), metaTitle: p.metaTitle || title }));
  };

  const handleSave = async () => {
    if (!form.title || !form.content) { setMsg('Title and content are required'); return; }
    setSaving(true);
    const data = { ...form, readTime: calculateReadTime(form.content), slug: form.slug || generateSlug(form.title) };
    try {
      if (view === 'edit' && editPost?.id) {
        await updatePost(editPost.id, data);
        setMsg('✅ Post updated!');
      } else {
        await createPost({ ...data, createdAt: new Date() });
        setMsg('✅ Post created!');
      }
      await loadPosts();
      setTimeout(() => { setView('list'); setMsg(''); }, 1500);
    } catch { setMsg('❌ Error saving post'); }
    setSaving(false);
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Delete this post?')) return;
    await deletePost(id);
    await loadPosts();
  };

  if (loading) return <div className="flex items-center justify-center h-64 text-sm" style={{ color: 'var(--text-muted)' }}>Loading…</div>;

  // Login Screen
  if (!user) return (
    <div className="min-h-screen flex items-center justify-center px-4" style={{ background: 'var(--bg)' }}>
      <div className="w-full max-w-sm">
        <div className="text-center mb-8">
          <div className="w-14 h-14 rounded-2xl flex items-center justify-center text-white text-2xl mx-auto mb-4" style={{ background: 'linear-gradient(135deg, #1a9e72, #e8920a)' }}>₹</div>
          <h1 className="font-serif text-2xl font-bold" style={{ color: 'var(--text-primary)' }}>Admin Login</h1>
          <p className="text-sm" style={{ color: 'var(--text-muted)' }}>FinTools India CMS</p>
        </div>
        <form onSubmit={login} className="rounded-2xl border p-6 space-y-4" style={{ background: 'var(--bg-card)', borderColor: 'var(--border)' }}>
          {loginError && <div className="text-xs text-center p-2 rounded-lg" style={{ background: 'var(--coral-light)', color: 'var(--coral)' }}>{loginError}</div>}
          <div>
            <label className="block text-sm font-semibold mb-1.5" style={{ color: 'var(--text-secondary)' }}>Email</label>
            <input type="email" required value={email} onChange={e => setEmail(e.target.value)} className="w-full px-4 py-2.5 rounded-xl border text-sm" style={{ background: 'var(--bg-subtle)', borderColor: 'var(--border)', color: 'var(--text-primary)', outline: 'none' }} placeholder="admin@example.com" />
          </div>
          <div>
            <label className="block text-sm font-semibold mb-1.5" style={{ color: 'var(--text-secondary)' }}>Password</label>
            <div className="relative">
              <input type={showPw ? 'text' : 'password'} required value={password} onChange={e => setPassword(e.target.value)} className="w-full px-4 py-2.5 rounded-xl border text-sm pr-10" style={{ background: 'var(--bg-subtle)', borderColor: 'var(--border)', color: 'var(--text-primary)', outline: 'none' }} />
              <button type="button" onClick={() => setShowPw(!showPw)} className="absolute right-3 top-1/2 -translate-y-1/2" style={{ color: 'var(--text-muted)' }}>
                {showPw ? <EyeOff size={15} /> : <Eye size={15} />}
              </button>
            </div>
          </div>
          <button type="submit" className="w-full py-2.5 rounded-xl text-sm font-semibold text-white" style={{ background: 'var(--emerald)' }}>Sign In</button>
        </form>
      </div>
    </div>
  );

  return (
    <div className="max-w-6xl mx-auto px-4 py-10">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="font-serif text-3xl font-bold" style={{ color: 'var(--text-primary)' }}>Blog Admin</h1>
          <p className="text-sm" style={{ color: 'var(--text-muted)' }}>Signed in as {user.email}</p>
        </div>
        <div className="flex gap-3">
          {view !== 'list' && (
            <button onClick={() => setView('list')} className="flex items-center gap-2 px-4 py-2 rounded-xl border text-sm" style={{ borderColor: 'var(--border)', color: 'var(--text-secondary)' }}>
              <X size={14} /> Cancel
            </button>
          )}
          {view === 'list' && (
            <button onClick={openCreate} className="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold text-white" style={{ background: 'var(--emerald)' }}>
              <Plus size={14} /> New Post
            </button>
          )}
          <button onClick={logout} className="flex items-center gap-2 px-4 py-2 rounded-xl border text-sm" style={{ borderColor: 'var(--border)', color: 'var(--text-secondary)' }}>
            <LogOut size={14} /> Logout
          </button>
        </div>
      </div>

      {/* Post List */}
      {view === 'list' && (
        <div className="space-y-3">
          <div className="flex items-center justify-between mb-4">
            <p className="text-sm" style={{ color: 'var(--text-muted)' }}>{posts.length} posts total</p>
          </div>
          {posts.length === 0 && (
            <div className="text-center py-20 rounded-2xl border" style={{ borderColor: 'var(--border)', background: 'var(--bg-card)' }}>
              <p className="text-4xl mb-3">📝</p>
              <p className="font-semibold mb-1" style={{ color: 'var(--text-primary)' }}>No posts yet</p>
              <p className="text-sm mb-4" style={{ color: 'var(--text-muted)' }}>Create your first blog post</p>
              <button onClick={openCreate} className="px-5 py-2.5 rounded-xl text-sm font-semibold text-white" style={{ background: 'var(--emerald)' }}>Create Post</button>
            </div>
          )}
          {posts.map(post => (
            <div key={post.id} className="rounded-2xl border p-5 flex items-start justify-between gap-4" style={{ background: 'var(--bg-card)', borderColor: 'var(--border)' }}>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-xs px-2 py-0.5 rounded-full font-semibold" style={{ background: 'var(--emerald-light)', color: 'var(--emerald)' }}>{post.category}</span>
                  <span className="text-xs px-2 py-0.5 rounded-full" style={{ background: post.published ? 'var(--emerald-light)' : 'var(--amber-light)', color: post.published ? 'var(--emerald)' : 'var(--amber)' }}>
                    {post.published ? 'Published' : 'Draft'}
                  </span>
                </div>
                <p className="font-semibold truncate" style={{ color: 'var(--text-primary)' }}>{post.title}</p>
                <p className="text-xs truncate" style={{ color: 'var(--text-muted)' }}>/blog/{post.slug}</p>
              </div>
              <div className="flex gap-2 shrink-0">
                <button onClick={() => openEdit(post)} className="p-2 rounded-lg border text-sm" style={{ borderColor: 'var(--border)', color: 'var(--text-secondary)' }}><Edit2 size={14} /></button>
                <button onClick={() => post.id && handleDelete(post.id)} className="p-2 rounded-lg border text-sm" style={{ borderColor: 'var(--border)', color: 'var(--coral)' }}><Trash2 size={14} /></button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Create / Edit Form */}
      {(view === 'create' || view === 'edit') && (
        <div className="rounded-2xl border p-6 space-y-5" style={{ background: 'var(--bg-card)', borderColor: 'var(--border)' }}>
          <h2 className="font-serif text-xl font-bold" style={{ color: 'var(--text-primary)' }}>
            {view === 'create' ? 'New Blog Post' : 'Edit Post'}
          </h2>
          {msg && <div className="text-sm p-3 rounded-xl" style={{ background: msg.startsWith('✅') ? 'var(--emerald-light)' : 'var(--coral-light)', color: msg.startsWith('✅') ? 'var(--emerald)' : 'var(--coral)' }}>{msg}</div>}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            <div className="md:col-span-2">
              <label className="block text-sm font-semibold mb-1.5" style={{ color: 'var(--text-secondary)' }}>Title *</label>
              <input type="text" value={form.title} onChange={e => handleTitleChange(e.target.value)} className="w-full px-4 py-2.5 rounded-xl border text-sm" style={{ background: 'var(--bg-subtle)', borderColor: 'var(--border)', color: 'var(--text-primary)', outline: 'none' }} placeholder="EMI Calculator India 2026" />
            </div>
            <div>
              <label className="block text-sm font-semibold mb-1.5" style={{ color: 'var(--text-secondary)' }}>Slug</label>
              <input type="text" value={form.slug} onChange={e => setForm(p => ({ ...p, slug: e.target.value }))} className="w-full px-4 py-2.5 rounded-xl border text-sm font-mono" style={{ background: 'var(--bg-subtle)', borderColor: 'var(--border)', color: 'var(--text-primary)', outline: 'none' }} />
            </div>
            <div>
              <label className="block text-sm font-semibold mb-1.5" style={{ color: 'var(--text-secondary)' }}>Category</label>
              <select value={form.category} onChange={e => setForm(p => ({ ...p, category: e.target.value }))} className="w-full px-4 py-2.5 rounded-xl border text-sm" style={{ background: 'var(--bg-subtle)', borderColor: 'var(--border)', color: 'var(--text-primary)', outline: 'none' }}>
                {['emi', 'sip', 'tax', 'fd', 'gst', 'general'].map(c => <option key={c} value={c}>{c.toUpperCase()}</option>)}
              </select>
            </div>
            <div className="md:col-span-2">
              <label className="block text-sm font-semibold mb-1.5" style={{ color: 'var(--text-secondary)' }}>Excerpt *</label>
              <textarea rows={2} value={form.excerpt} onChange={e => setForm(p => ({ ...p, excerpt: e.target.value }))} className="w-full px-4 py-2.5 rounded-xl border text-sm resize-none" style={{ background: 'var(--bg-subtle)', borderColor: 'var(--border)', color: 'var(--text-primary)', outline: 'none' }} placeholder="Short description shown on blog card..." />
            </div>
            <div>
              <label className="block text-sm font-semibold mb-1.5" style={{ color: 'var(--text-secondary)' }}>Meta Title (SEO)</label>
              <input type="text" value={form.metaTitle} onChange={e => setForm(p => ({ ...p, metaTitle: e.target.value }))} className="w-full px-4 py-2.5 rounded-xl border text-sm" style={{ background: 'var(--bg-subtle)', borderColor: 'var(--border)', color: 'var(--text-primary)', outline: 'none' }} />
            </div>
            <div>
              <label className="block text-sm font-semibold mb-1.5" style={{ color: 'var(--text-secondary)' }}>Meta Description (SEO)</label>
              <input type="text" value={form.metaDescription} onChange={e => setForm(p => ({ ...p, metaDescription: e.target.value }))} className="w-full px-4 py-2.5 rounded-xl border text-sm" style={{ background: 'var(--bg-subtle)', borderColor: 'var(--border)', color: 'var(--text-primary)', outline: 'none' }} />
            </div>
            <div className="md:col-span-2">
              <label className="block text-sm font-semibold mb-1.5" style={{ color: 'var(--text-secondary)' }}>Content (HTML) *</label>
              <textarea rows={18} value={form.content} onChange={e => setForm(p => ({ ...p, content: e.target.value }))} className="w-full px-4 py-3 rounded-xl border text-sm font-mono resize-y" style={{ background: 'var(--bg-subtle)', borderColor: 'var(--border)', color: 'var(--text-primary)', outline: 'none' }} placeholder="<h2>Introduction</h2><p>Your blog content here...</p>" />
            </div>
            <div className="flex items-center gap-3">
              <input type="checkbox" id="published" checked={form.published} onChange={e => setForm(p => ({ ...p, published: e.target.checked }))} className="w-4 h-4 rounded" />
              <label htmlFor="published" className="text-sm font-semibold" style={{ color: 'var(--text-secondary)' }}>Published (visible on site)</label>
            </div>
          </div>

          <div className="flex gap-3 pt-2 border-t" style={{ borderColor: 'var(--border)' }}>
            <button onClick={handleSave} disabled={saving} className="flex items-center gap-2 px-6 py-2.5 rounded-xl text-sm font-semibold text-white disabled:opacity-60" style={{ background: 'var(--emerald)' }}>
              <Save size={14} /> {saving ? 'Saving…' : 'Save Post'}
            </button>
            <button onClick={() => setView('list')} className="px-5 py-2.5 rounded-xl border text-sm font-medium" style={{ borderColor: 'var(--border)', color: 'var(--text-secondary)' }}>Cancel</button>
          </div>
        </div>
      )}
    </div>
  );
}
