import type { Metadata } from 'next';
import Link from 'next/link';

export const metadata: Metadata = {
  title: 'Privacy Policy – FinTools India',
  description: 'Privacy Policy for FinTools India. Learn how we collect, use, and protect your information.',
};

export default function PrivacyPolicyPage() {
  return (
    <div className="max-w-3xl mx-auto px-4 py-16">
      <nav className="text-xs mb-6 flex items-center gap-2" style={{ color: 'var(--text-muted)' }}>
        <Link href="/" className="hover:underline">Home</Link> / <span style={{ color: 'var(--emerald)' }}>Privacy Policy</span>
      </nav>
      <h1 className="font-serif text-4xl font-bold mb-2" style={{ color: 'var(--text-primary)' }}>Privacy Policy</h1>
      <p className="text-sm mb-8" style={{ color: 'var(--text-muted)' }}>Last updated: January 1, 2025</p>

      <div className="space-y-8" style={{ color: 'var(--text-secondary)' }}>
        {[
          {
            title: '1. Information We Collect',
            body: `We collect information you provide directly (name, email via contact form) and information collected automatically (pages visited, browser type, IP address, device type) via Google Analytics. We do not collect financial data entered in our calculators — all calculations happen in your browser.`,
          },
          {
            title: '2. How We Use Your Information',
            body: `We use the information we collect to: operate and improve our website, respond to your inquiries, analyze usage patterns to improve user experience, and display relevant advertisements via Google AdSense.`,
          },
          {
            title: '3. Google AdSense & Cookies',
            body: `We use Google AdSense to serve advertisements. Google uses cookies to show ads based on your prior visits to our website and other websites. You can opt out of personalized advertising by visiting Google's Ad Settings. We also use Google Analytics to understand site usage.`,
          },
          {
            title: '4. Data Security',
            body: `We implement industry-standard security measures. However, no method of transmission over the Internet is 100% secure. Calculator inputs are NOT stored on our servers — they are processed entirely in your browser.`,
          },
          {
            title: '5. Third-Party Links',
            body: `Our website may contain links to third-party websites. We are not responsible for the privacy practices of those sites. We encourage you to review their privacy policies.`,
          },
          {
            title: '6. Children\'s Privacy',
            body: `Our services are not directed at children under 13 years of age. We do not knowingly collect personal information from children.`,
          },
          {
            title: '7. Changes to This Policy',
            body: `We may update this Privacy Policy from time to time. We will notify you of changes by updating the "Last updated" date at the top of this page.`,
          },
          {
            title: '8. Contact Us',
            body: `If you have questions about this Privacy Policy, contact us at: hello@fintoolsindia.in`,
          },
        ].map(s => (
          <section key={s.title}>
            <h2 className="font-serif text-xl font-bold mb-3" style={{ color: 'var(--text-primary)' }}>{s.title}</h2>
            <p className="text-sm leading-relaxed">{s.body}</p>
          </section>
        ))}
      </div>
    </div>
  );
}
