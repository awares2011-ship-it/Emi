'use client';
import { useState } from 'react';
import Link from 'next/link';
import { Send, Check } from 'lucide-react';

export default function ContactPage() {
  const [form, setForm] = useState({ name: '', email: '', subject: '', message: '' });
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    // Replace with your form backend (Formspree, Firebase, etc.)
    await new Promise(r => setTimeout(r, 1000));
    setSubmitted(true);
    setLoading(false);
  };

  return (
    <div className="max-w-2xl mx-auto px-4 py-16">
      <nav className="text-xs mb-6 flex items-center gap-2" style={{ color: 'var(--text-muted)' }}>
        <Link href="/" className="hover:underline">Home</Link> / <span style={{ color: 'var(--emerald)' }}>Contact</span>
      </nav>

      <h1 className="font-serif text-4xl font-bold mb-3" style={{ color: 'var(--text-primary)' }}>Contact Us</h1>
      <p className="mb-8" style={{ color: 'var(--text-secondary)' }}>Found a bug? Have a suggestion? Want to advertise? We'd love to hear from you.</p>

      {submitted ? (
        <div className="text-center py-16">
          <div className="w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4" style={{ background: 'var(--emerald-light)' }}>
            <Check size={28} style={{ color: 'var(--emerald)' }} />
          </div>
          <h2 className="font-serif text-2xl font-bold mb-2" style={{ color: 'var(--text-primary)' }}>Message Sent!</h2>
          <p style={{ color: 'var(--text-secondary)' }}>We'll get back to you within 24–48 hours.</p>
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="space-y-5">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            <div>
              <label className="block text-sm font-semibold mb-2" style={{ color: 'var(--text-secondary)' }}>Name *</label>
              <input required type="text" value={form.name} onChange={e => setForm(p => ({ ...p, name: e.target.value }))} className="w-full px-4 py-3 rounded-xl border text-sm" style={{ background: 'var(--bg-subtle)', borderColor: 'var(--border)', color: 'var(--text-primary)', outline: 'none' }} placeholder="Your name" />
            </div>
            <div>
              <label className="block text-sm font-semibold mb-2" style={{ color: 'var(--text-secondary)' }}>Email *</label>
              <input required type="email" value={form.email} onChange={e => setForm(p => ({ ...p, email: e.target.value }))} className="w-full px-4 py-3 rounded-xl border text-sm" style={{ background: 'var(--bg-subtle)', borderColor: 'var(--border)', color: 'var(--text-primary)', outline: 'none' }} placeholder="your@email.com" />
            </div>
          </div>
          <div>
            <label className="block text-sm font-semibold mb-2" style={{ color: 'var(--text-secondary)' }}>Subject *</label>
            <select required value={form.subject} onChange={e => setForm(p => ({ ...p, subject: e.target.value }))} className="w-full px-4 py-3 rounded-xl border text-sm" style={{ background: 'var(--bg-subtle)', borderColor: 'var(--border)', color: 'var(--text-primary)', outline: 'none' }}>
              <option value="">Select subject</option>
              <option>Bug Report</option>
              <option>Feature Request</option>
              <option>Advertising Inquiry</option>
              <option>Content Feedback</option>
              <option>Other</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-semibold mb-2" style={{ color: 'var(--text-secondary)' }}>Message *</label>
            <textarea required rows={5} value={form.message} onChange={e => setForm(p => ({ ...p, message: e.target.value }))} className="w-full px-4 py-3 rounded-xl border text-sm resize-none" style={{ background: 'var(--bg-subtle)', borderColor: 'var(--border)', color: 'var(--text-primary)', outline: 'none' }} placeholder="Describe your query in detail..." />
          </div>
          <button type="submit" disabled={loading} className="flex items-center gap-2 px-6 py-3 rounded-xl text-sm font-semibold text-white transition-opacity disabled:opacity-60" style={{ background: 'var(--emerald)' }}>
            <Send size={15} /> {loading ? 'Sending...' : 'Send Message'}
          </button>
        </form>
      )}

      <div className="mt-10 p-5 rounded-2xl border" style={{ background: 'var(--bg-subtle)', borderColor: 'var(--border)' }}>
        <p className="text-sm font-semibold mb-1" style={{ color: 'var(--text-primary)' }}>Email</p>
        <p className="text-sm" style={{ color: 'var(--text-muted)' }}>hello@fintoolsindia.in</p>
      </div>
    </div>
  );
}
