// lib/blog.ts
import { collection, getDocs, getDoc, doc, addDoc, updateDoc, deleteDoc, query, orderBy, limit, where, Timestamp } from 'firebase/firestore';
import { db } from './firebase';

export interface BlogPost {
  id?: string;
  title: string;
  slug: string;
  content: string;
  excerpt: string;
  metaTitle: string;
  metaDescription: string;
  category: string;
  tags: string[];
  createdAt: Date | Timestamp;
  updatedAt?: Date | Timestamp;
  published: boolean;
  readTime?: number;
}

export async function getAllPosts(publishedOnly = true): Promise<BlogPost[]> {
  try {
    const postsRef = collection(db, 'posts');
    let q;
    if (publishedOnly) {
      q = query(postsRef, where('published', '==', true), orderBy('createdAt', 'desc'));
    } else {
      q = query(postsRef, orderBy('createdAt', 'desc'));
    }
    const snapshot = await getDocs(q);
    return snapshot.docs.map(d => ({ id: d.id, ...d.data() } as BlogPost));
  } catch (error) {
    console.error('Error fetching posts:', error);
    return [];
  }
}

export async function getPostBySlug(slug: string): Promise<BlogPost | null> {
  try {
    const postsRef = collection(db, 'posts');
    const q = query(postsRef, where('slug', '==', slug), limit(1));
    const snapshot = await getDocs(q);
    if (snapshot.empty) return null;
    const d = snapshot.docs[0];
    return { id: d.id, ...d.data() } as BlogPost;
  } catch (error) {
    console.error('Error fetching post:', error);
    return null;
  }
}

export async function getRecentPosts(count = 3): Promise<BlogPost[]> {
  try {
    const postsRef = collection(db, 'posts');
    const q = query(postsRef, where('published', '==', true), orderBy('createdAt', 'desc'), limit(count));
    const snapshot = await getDocs(q);
    return snapshot.docs.map(d => ({ id: d.id, ...d.data() } as BlogPost));
  } catch (error) {
    console.error('Error fetching recent posts:', error);
    return [];
  }
}

export async function createPost(post: Omit<BlogPost, 'id'>): Promise<string> {
  const docRef = await addDoc(collection(db, 'posts'), {
    ...post,
    createdAt: Timestamp.now(),
    updatedAt: Timestamp.now(),
  });
  return docRef.id;
}

export async function updatePost(id: string, post: Partial<BlogPost>): Promise<void> {
  const docRef = doc(db, 'posts', id);
  await updateDoc(docRef, { ...post, updatedAt: Timestamp.now() });
}

export async function deletePost(id: string): Promise<void> {
  await deleteDoc(doc(db, 'posts', id));
}

export function calculateReadTime(content: string): number {
  const words = content.split(/\s+/).length;
  return Math.ceil(words / 200);
}

export function generateSlug(title: string): string {
  return title
    .toLowerCase()
    .replace(/[^a-z0-9\s-]/g, '')
    .replace(/\s+/g, '-')
    .replace(/-+/g, '-')
    .trim();
}
