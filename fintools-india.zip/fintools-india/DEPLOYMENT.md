# FinTools India – Complete Setup & Deployment Guide

## Prerequisites
- Node.js 18+ installed
- Google account (for Firebase & AdSense)
- Domain name (optional but recommended for AdSense)

---

## Step 1: Install Dependencies

```bash
cd fintools-india
npm install
```

---

## Step 2: Firebase Setup

### 2.1 Create Firebase Project
1. Go to https://console.firebase.google.com
2. Click **"Add project"**
3. Name it: `fintools-india` (or your preferred name)
4. Enable Google Analytics when prompted

### 2.2 Enable Required Services
In Firebase Console, enable:
- **Firestore Database** → Create database → Start in **production mode** → Choose `asia-south1` (Mumbai) region
- **Authentication** → Sign-in method → Enable **Email/Password**
- **Hosting** → Get started

### 2.3 Get Firebase Config
1. Project Settings → General → Your Apps
2. Click **"Add app"** → Web (`</>`)
3. Register app name: `fintools-india-web`
4. Copy the `firebaseConfig` object

### 2.4 Create Admin User
1. Firebase Console → Authentication → Users → Add user
2. Enter your admin email and a strong password
3. This is your blog admin login

### 2.5 Deploy Firestore Security Rules
```bash
npm install -g firebase-tools
firebase login
firebase init firestore
firebase deploy --only firestore:rules
```

---

## Step 3: Environment Variables

Create `.env.local` file:

```bash
cp .env.example .env.local
```

Fill in all values from your Firebase project settings:

```env
NEXT_PUBLIC_FIREBASE_API_KEY=AIzaSy...
NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN=your-project.firebaseapp.com
NEXT_PUBLIC_FIREBASE_PROJECT_ID=your-project-id
NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET=your-project.appspot.com
NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID=123456789
NEXT_PUBLIC_FIREBASE_APP_ID=1:123456789:web:abcdef
NEXT_PUBLIC_FIREBASE_MEASUREMENT_ID=G-XXXXXXXXXX
NEXT_PUBLIC_GA_ID=G-XXXXXXXXXX
NEXT_PUBLIC_ADSENSE_CLIENT_ID=ca-pub-XXXXXXXXXXXXXXXX
```

---

## Step 4: Run Locally

```bash
npm run dev
```

Open http://localhost:3000

---

## Step 5: Seed Blog Posts

```bash
# Download serviceAccountKey.json from:
# Firebase Console → Project Settings → Service Accounts → Generate new private key

npm install firebase-admin
node scripts/seedBlog.js
```

This seeds 10 blog posts with full SEO content.

---

## Step 6: Deploy to Firebase Hosting

### Option A: Firebase Hosting (Recommended for India)

```bash
# Build the project
npm run build

# Install Firebase CLI
npm install -g firebase-tools

# Login and init
firebase login
firebase init hosting

# When prompted:
# - Public directory: out
# - Single-page app: Yes
# - Overwrite index.html: No

# Add to next.config.js:
# output: 'export'

# Deploy
firebase deploy --only hosting
```

### Option B: Vercel (Easiest - Recommended for Next.js)

```bash
npm install -g vercel
vercel

# Follow prompts
# Add env variables in Vercel Dashboard
```

Vercel URL: `your-project.vercel.app`

### Option C: Deploy on VPS (Ubuntu)

```bash
# On your server
git clone your-repo
cd fintools-india
npm install
npm run build
npm install -g pm2
pm2 start npm --name "fintools" -- start
pm2 save
```

---

## Step 7: Custom Domain Setup

### For Vercel:
1. Vercel Dashboard → Your Project → Settings → Domains
2. Add `fintoolsindia.in`
3. Update DNS A record at your domain registrar:
   - Type: A | Name: @ | Value: 76.76.19.61
4. Add CNAME for www:
   - Type: CNAME | Name: www | Value: cname.vercel-dns.com

### For Firebase Hosting:
1. Firebase Console → Hosting → Add custom domain
2. Add `fintoolsindia.in`
3. Follow verification steps
4. Update DNS records as instructed

**Recommended domain registrars for .in domains:**
- GoDaddy India
- BigRock
- Hostinger India
- Google Domains

---

## Step 8: Google Analytics Setup

1. Go to https://analytics.google.com
2. Create account → Create property
3. Platform: Web
4. Enter your domain
5. Copy Measurement ID (G-XXXXXXXXXX)
6. Add to `.env.local` as `NEXT_PUBLIC_GA_ID`

**Setup Google Search Console:**
1. https://search.google.com/search-console
2. Add property → Domain → Enter `fintoolsindia.in`
3. Verify via DNS TXT record
4. Submit sitemap: `https://fintoolsindia.in/sitemap.xml`

---

## Step 9: Google AdSense Setup

**Requirements for AdSense approval:**
- [ ] Original content (blog posts)
- [ ] Legal pages: Privacy Policy, Terms, Disclaimer, About, Contact
- [ ] HTTPS enabled
- [ ] No copyright violation
- [ ] Sufficient content (aim for 10+ blog posts)
- [ ] Mobile responsive (✅ already done)

**Apply for AdSense:**
1. https://www.google.com/adsense/start
2. Enter your website URL
3. Add AdSense code to `<head>` in `app/layout.tsx`:

```jsx
<Script
  async
  src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-XXXXXXXXXXXXXXXX"
  crossOrigin="anonymous"
  strategy="afterInteractive"
/>
```

4. Wait for approval (usually 2–4 weeks for new sites)
5. Once approved, replace slot IDs in `AdBanner` components

**Ad Unit Slots to Create in AdSense:**
- Display Ad (Header) → 728×90
- Display Ad (In-content) → 336×280 
- Display Ad (Sidebar) → 300×250

---

## Step 10: SEO Optimization Checklist

- [ ] Submit sitemap to Google Search Console
- [ ] Add Google Analytics
- [ ] Enable Google Search Console → Core Web Vitals report
- [ ] Add structured data testing via https://search.google.com/test/rich-results
- [ ] Test mobile friendliness: https://search.google.com/test/mobile-friendly
- [ ] Check PageSpeed: https://pagespeed.web.dev
- [ ] Set up Bing Webmaster Tools (additional traffic source)

---

## Step 11: Post-Launch Content Strategy

**Week 1-2:** Publish 5 more blog posts targeting:
- "SIP calculator 2026"
- "GST calculator for freelancers"
- "NPS vs EPF comparison"
- "Home loan tax benefits"
- "Mutual fund taxation India"

**Week 3-4:** 
- Build backlinks from finance forums (Quora, Reddit r/IndiaInvestments)
- Share on social media
- Submit to Google News if eligible

**Monthly:**
- Update interest rate data in articles
- Add new calculator tools
- Increase blog frequency to 2-3 posts/week

---

## Performance Optimization

The project already includes:
- ✅ Next.js automatic code splitting
- ✅ Image optimization (next/image)
- ✅ Font preloading
- ✅ Lazy loading (React lazy + Suspense)
- ✅ CSS-in-JS via Tailwind (minimal CSS bundle)

To achieve Lighthouse 90+:
1. Run `npm run build && npm run start`
2. Test with Chrome DevTools → Lighthouse
3. Ensure all images have `alt` attributes
4. Check CLS (avoid layout shifts)

---

## Admin Panel Access

URL: `https://yourdomain.in/admin`

Login with:
- Email: The admin email you created in Firebase Auth
- Password: Your admin password

Features:
- Create new blog posts (HTML editor)
- Edit existing posts
- Publish/unpublish posts
- Delete posts
- Auto-generates slug and read time

---

## Support

For issues, check:
- Firebase docs: https://firebase.google.com/docs
- Next.js docs: https://nextjs.org/docs
- Tailwind docs: https://tailwindcss.com/docs

Need help? Email: hello@fintoolsindia.in
